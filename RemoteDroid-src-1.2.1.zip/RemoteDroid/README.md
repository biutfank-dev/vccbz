# RemoteDroid - 安卓对安卓远程控制

安卓设备间的屏幕共享与双向远程控制应用。

## v1.2.1 修复说明

- 【闪退修复】"主控端连接被控端"相关崩溃全面加固：
  - 视频流客户端/服务器的接收线程逐条消息捕获异常，坏数据不再导致进程崩溃；
  - 被控端动态改分辨率/码率（reconfigure）增加幂等判断与重入保护，参数未变不重建；
  - 编码器停止流程改为「先stop编码线程、join、再释放」，消除释放竞态导致的偶发原生崩溃；
  - 控制器解码器启动/停止/重建全部收敛到主线程，与Surface生命周期串行，Surface销毁立即停解码；
  - 收到新的SPS/PPS或编码分辨率变化时自动重建解码器；SPS/PPS解析重写（兼容3/4字节起始码）；
  - 新增编码分辨率下发（MSG_ENCODE_INFO），解码器用实际编码尺寸初始化，中间加入也能顺利起播；
  - 音频播放/采集、UDP扫描、Root检测等全链路异常兜底，任何回调异常均不会闪退。
- 【界面修复】主控端"分辨率/码率"下拉框改用与应用其他输入框一致的描边风格（12dp圆角），
  配色、间距与整体布局统一；被控端"启动/停止"按钮改用背景色调（保留圆角与波纹效果）。

## v1.1 闪退修复说明

- 修复 Android 10+ 前台服务未指定类型导致的崩溃
- 修复 Android 14+ MediaProjection 未注册 Callback 的 SecurityException
- 编码尺寸对齐到 16，兼容老设备/32位设备
- Root 模式改用持久 Shell，避免每次触摸 fork 进程导致 ANR
- 触摸改为「点击/滑动」完整手势识别，提升无障碍模式成功率
- 新增全局崩溃日志（存储在 App 外部文件目录 logs/）
- 适配 Android 7.0 (API24) 至 Android 15+，纯 Java 自动兼容 32/64 位
- 移除会引发异常的 flagRequestTouchExplorationMode

## 功能特性

- 屏幕实时共享（H264硬编码，MediaProjection）
- 双向触摸控制（Root模式 / 无障碍服务模式）
- 同一WiFi下自动发现设备（UDP广播）
- 手动IP连接
- Material Design 原生风格UI

## 系统要求

- Android 5.0 (API 21) 及以上
- 两台设备连接同一WiFi
- 被控端需开启屏幕录制权限
- 触摸控制需Root或开启无障碍服务

## 使用方法

### 被控端（共享屏幕的设备）
1. 打开App，默认在"被控端"标签页
2. 选择触摸注入模式：
   - **Root模式**：设备已Root时可选，通过`input`命令注入触摸
   - **无障碍模式**：需先开启"RemoteDroid"无障碍服务
3. 点击"开始共享屏幕"，授予屏幕录制权限
4. 页面显示IP地址和端口，等待控制端连接

### 控制端（操作对方设备）
1. 切换到"控制端"标签页
2. 点击"扫描设备"自动发现同一WiFi下的被控端
3. 或手动输入IP地址和端口（默认8888）
4. 点击设备或"连接"按钮
5. 连接成功后即可看到对方屏幕，点击/滑动即可远程操作

## 触摸注入模式说明

| 模式 | 要求 | 原理 |
|------|------|------|
| Root | 设备已Root | 执行`input tap/swipe`命令 |
| 无障碍 | 开启无障碍服务 | AccessibilityService.dispatchGesture |

## 项目结构

```
app/src/main/java/com/remotedroid/app/
├── ui/                    # 界面
│   ├── MainActivity.java      # 主界面（Tab切换）
│   ├── HostFragment.java      # 被控端
│   ├── ControlFragment.java   # 控制端
│   ├── RemoteActivity.java    # 远程控制画面
│   └── DeviceAdapter.java     # 设备列表
├── service/               # 服务
│   ├── ScreenCastService.java # 屏幕采集前台服务
│   ├── RemoteAccessibilityService.java # 无障碍服务
│   ├── H264Encoder.java       # H264编码器
│   └── H264Decoder.java       # H264解码器
├── net/                   # 网络
│   ├── UdpDiscovery.java      # UDP设备发现
│   ├── VideoStreamServer.java # 视频流服务器（被控端）
│   └── VideoStreamClient.java # 视频流客户端（控制端）
└── util/                  # 工具
    ├── NetUtil.java           # 网络工具
    └── TouchInjector.java     # 触摸注入
```

## 编译

```bash
# 使用Gradle Wrapper
./gradlew assembleDebug

# 输出位置
app/build/outputs/apk/debug/app-debug.apk
```

## AIDE导入

1. 将项目文件夹复制到手机
2. AIDE中选择"打开项目"，选择项目根目录
3. 等待Gradle同步完成
4. 点击运行即可编译安装

## 注意事项

- 本应用仅用于合法的远程协助和个人设备管理
- 首次使用需授予屏幕录制权限
- 无障碍服务需在系统设置中手动开启
- Root模式需要设备已获取Root权限
- 视频流通过局域网传输，不经过互联网服务器
