package com.remotedroid.app.service;

import android.media.MediaCodec;
import android.media.MediaFormat;
import android.util.Log;
import android.view.Surface;

import java.io.IOException;
import java.nio.ByteBuffer;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.atomic.AtomicBoolean;

/**
 * H264解码器：将收到的视频帧解码渲染到Surface。
 *
 * 稳定性说明（v1.2.1）：
 * - SPS/PPS（csd-0/csd-1）解析重写，兼容3/4字节起始码，不再越界；
 * - 输入缓冲容量校验，帧过大时安全丢弃而不是抛异常；
 * - 每个关键帧都会打上 BUFFER_FLAG_KEY_FRAME 标记，部分机型中间加入也能顺利起播；
 * - 所有方法线程安全（synchronized），解码线程与主线程停止/重建不会相互踩踏。
 */
public class H264Decoder {

    private static final String TAG = "H264Decoder";
    private static final String MIME_TYPE = "video/avc";

    private MediaCodec codec;
    private final Surface outputSurface;
    private final AtomicBoolean running = new AtomicBoolean(false);
    private int width;
    private int height;
    private byte[] codecConfig;

    public H264Decoder(Surface surface, int width, int height) {
        this.outputSurface = surface;
        this.width = width;
        this.height = height;
    }

    // ==================== NAL 解析工具 ====================

    private static boolean isStartCodeAt(byte[] d, int i) {
        return i + 4 <= d.length && d[i] == 0 && d[i + 1] == 0 && d[i + 2] == 0 && d[i + 3] == 1;
    }

    private static boolean isShortStartCodeAt(byte[] d, int i) {
        return i + 3 <= d.length && d[i] == 0 && d[i + 1] == 0 && d[i + 2] == 1;
    }

    private static int startCodeLength(byte[] d, int i) {
        if (isStartCodeAt(d, i)) return 4;
        if (isShortStartCodeAt(d, i)) return 3;
        return 0;
    }

    /** 返回NAL类型（1=非IDR片,5=IDR片,7=SPS,8=PPS...），无法识别返回-1 */
    private static int nalType(byte[] nal) {
        int sc = startCodeLength(nal, 0);
        if (sc <= 0) return -1;
        int headerIndex = sc;
        if (headerIndex >= nal.length) return -1;
        return nal[headerIndex] & 0x1F;
    }

    /** 拆出所有NAL（含起始码） */
    private static List<byte[]> splitNals(byte[] data) {
        List<byte[]> result = new ArrayList<>();
        int start = -1;
        int i = 0;
        while (i + 3 <= data.length) {
            int sc = startCodeLength(data, i);
            if (sc > 0) {
                if (start >= 0 && i > start) {
                    result.add(java.util.Arrays.copyOfRange(data, start, i));
                }
                start = i;
                i += sc;
            } else {
                i++;
            }
        }
        if (start >= 0 && start < data.length) {
            result.add(java.util.Arrays.copyOfRange(data, start, data.length));
        }
        return result;
    }

    private static void splitAndSetCsd(MediaFormat format, byte[] config) {
        List<byte[]> nals = splitNals(config);
        for (byte[] nal : nals) {
            int type = nalType(nal);
            if (type == 7) {
                format.setByteBuffer("csd-0", ByteBuffer.wrap(nal));
            } else if (type == 8) {
                format.setByteBuffer("csd-1", ByteBuffer.wrap(nal));
            }
        }
    }

    /** 扫描该帧是否包含IDR图像（关键帧），不含则返回false，无法判断按true处理 */
    private static boolean isKeyFrame(byte[] data) {
        int i = 0;
        while (i + 3 <= data.length) {
            int sc = startCodeLength(data, i);
            if (sc <= 0) {
                i++;
                continue;
            }
            int h = i + sc;
            if (h >= data.length) break;
            int type = data[h] & 0x1F;
            if (type == 1 || type == 5) {
                return type == 5;
            }
            i = h;
        }
        return true;
    }

    // ==================== 生命周期 ====================

    public synchronized void start() throws IOException {
        try {
            int w = Math.max(16, width);
            int h = Math.max(16, height);
            MediaFormat format = MediaFormat.createVideoFormat(MIME_TYPE, w, h);
            if (codecConfig != null) {
                try {
                    splitAndSetCsd(format, codecConfig);
                } catch (Throwable t) {
                    Log.w(TAG, "set csd failed (will rely on in-band SPS/PPS)", t);
                }
            }
            codec = MediaCodec.createDecoderByType(MIME_TYPE);
            codec.configure(format, outputSurface, null, 0);
            codec.start();
            running.set(true);
            Log.i(TAG, "Decoder started: " + w + "x" + h);
        } catch (Throwable t) {
            releaseQuietly();
            if (t instanceof IOException) throw (IOException) t;
            throw new IOException("Decoder start failed", t);
        }
    }

    public synchronized void setCodecConfig(byte[] config) {
        this.codecConfig = config;
    }

    /**
     * 解码一帧（线程安全）。任何异常都会被吞掉，避免接收线程被致命错误带走。
     */
    public synchronized void decodeFrame(byte[] data, long presentationTimeUs) {
        MediaCodec c = codec;
        if (!running.get() || c == null || data == null || data.length == 0) return;
        try {
            int inputBufferId = c.dequeueInputBuffer(10000);
            if (inputBufferId >= 0) {
                ByteBuffer inputBuffer = c.getInputBuffer(inputBufferId);
                if (inputBuffer == null || data.length > inputBuffer.capacity()) {
                    // 帧过大无法放入，安全丢弃（不会抛异常）
                    c.queueInputBuffer(inputBufferId, 0, 0, Math.max(0, presentationTimeUs), 0);
                    Log.w(TAG, "Frame too large for decoder input buffer: " + data.length
                            + " (capacity=" + (inputBuffer != null ? inputBuffer.capacity() : -1) + ")");
                } else {
                    inputBuffer.clear();
                    inputBuffer.put(data);
                    int flags = isKeyFrame(data) ? MediaCodec.BUFFER_FLAG_KEY_FRAME : 0;
                    c.queueInputBuffer(inputBufferId, 0, data.length,
                            Math.max(0, presentationTimeUs), flags);
                }
            }

            MediaCodec.BufferInfo bufferInfo = new MediaCodec.BufferInfo();
            for (int guard = 0; guard < 12; guard++) {
                int outputBufferId = c.dequeueOutputBuffer(bufferInfo, 0);
                if (outputBufferId >= 0) {
                    c.releaseOutputBuffer(outputBufferId, true);
                } else if (outputBufferId == MediaCodec.INFO_OUTPUT_FORMAT_CHANGED) {
                    Log.i(TAG, "Decoder output format changed: " + c.getOutputFormat());
                } else {
                    break;
                }
            }
        } catch (Throwable t) {
            Log.w(TAG, "Decode error (frame skipped)", t);
        }
    }

    public synchronized void stop() {
        running.set(false);
        releaseQuietly();
        Log.i(TAG, "Decoder stopped");
    }

    private void releaseQuietly() {
        MediaCodec c = codec;
        codec = null;
        if (c != null) {
            try { c.stop(); } catch (Throwable ignore) {}
            try { c.release(); } catch (Throwable ignore) {}
        }
    }
}
