package com.remotedroid.app.util;

import android.accessibilityservice.GestureDescription;
import android.graphics.Path;
import android.os.Build;
import android.util.Log;

import com.remotedroid.app.service.RemoteAccessibilityService;

import java.io.DataOutputStream;

public class TouchInjector {

    private static final String TAG = "TouchInjector";

    // 持久Root Shell（避免每次触摸都fork su进程，否则会ANR/卡顿）
    private static Process rootProcess;
    private static DataOutputStream rootStream;
    private static boolean rootInitStarted = false;
    private static Boolean rootAvailable = null;

    public static synchronized boolean isRootAvailable() {
        if (rootAvailable != null) return rootAvailable;
        if (rootInitStarted) return false;
        rootInitStarted = true;
        Process process = null;
        try {
            process = Runtime.getRuntime().exec("su");
            final DataOutputStream os = new DataOutputStream(process.getOutputStream());
            os.writeBytes("echo ROOT_OK\n");
            os.flush();

            // 带超时地读取响应，避免 su 弹窗等待导致永久阻塞
            final Process p = process;
            java.util.concurrent.Future<String> future =
                    java.util.concurrent.Executors.newSingleThreadExecutor()
                            .submit(() -> {
                                byte[] buf = new byte[128];
                                int n = p.getInputStream().read(buf);
                                return n > 0 ? new String(buf, 0, n) : "";
                            });
            String resp;
            try {
                resp = future.get(3, java.util.concurrent.TimeUnit.SECONDS);
            } catch (Exception timeout) {
                future.cancel(true);
                // 超时（多半是su弹窗等待中）：结束该进程避免泄漏，本次判定为不可用
                try { process.destroy(); } catch (Throwable ignore) {}
                resp = "";
            }

            rootAvailable = resp != null && resp.contains("ROOT_OK");
            if (rootAvailable) {
                rootProcess = process;
                rootStream = os;
            } else {
                try { os.writeBytes("exit\n"); os.flush(); } catch (Exception e) {}
                try { process.waitFor(); } catch (Exception e) {}
            }
        } catch (Throwable e) {
            rootAvailable = false;
            if (process != null) {
                try { process.destroy(); } catch (Throwable ignore) {}
            }
        }
        return rootAvailable;
    }

    /**
     * 注入触摸事件
     * @param useRoot true=root, false=无障碍
     * @param action 0=down/tap, 1=up, 2=move
     */
    public static void injectTouch(boolean useRoot, int action, float x, float y, int meta) {
        try {
            if (useRoot) {
                injectTouchRoot(action, x, y);
            } else {
                injectTouchA11y(action, x, y);
            }
        } catch (Throwable t) {
            Log.e(TAG, "injectTouch failed", t);
        }
    }

    private static synchronized void injectTouchRoot(int action, float x, float y) {
        ensureRootShell();
        if (rootStream == null) return;
        try {
            int ix = Math.max(0, Math.round(x));
            int iy = Math.max(0, Math.round(y));
            if (action == 0) {
                // tap 包含 down+up
                rootStream.writeBytes("input tap " + ix + " " + iy + "\n");
                rootStream.flush();
            }
            // action 1 (up) 和 2 (move) 不单独处理，move用swipe路径
        } catch (Exception e) {
            Log.e(TAG, "Root touch failed, restarting shell", e);
            closeRootShell();
        }
    }

    public static synchronized void injectSwipe(boolean useRoot,
            float x1, float y1, float x2, float y2, int durationMs) {
        try {
            if (useRoot) {
                ensureRootShell();
                if (rootStream == null) return;
                rootStream.writeBytes("input swipe "
                        + Math.round(x1) + " " + Math.round(y1) + " "
                        + Math.round(x2) + " " + Math.round(y2) + " "
                        + Math.max(50, durationMs) + "\n");
                rootStream.flush();
            } else {
                injectSwipeA11y(x1, y1, x2, y2, durationMs);
            }
        } catch (Exception e) {
            Log.e(TAG, "Swipe failed", e);
            if (useRoot) closeRootShell();
        }
    }

    private static void ensureRootShell() {
        if (rootStream != null) return;
        try {
            rootProcess = Runtime.getRuntime().exec("su");
            rootStream = new DataOutputStream(rootProcess.getOutputStream());
        } catch (Exception e) {
            Log.e(TAG, "Failed to start root shell", e);
            rootStream = null;
        }
    }

    private static void closeRootShell() {
        if (rootStream != null) {
            try { rootStream.writeBytes("exit\n"); rootStream.flush(); } catch (Exception e) {}
            rootStream = null;
        }
        if (rootProcess != null) {
            rootProcess.destroy();
            rootProcess = null;
        }
    }

    // ============ 无障碍模式 ============

    private static void injectTouchA11y(int action, float x, float y) {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.N) return;
        RemoteAccessibilityService svc = RemoteAccessibilityService.getInstance();
        if (svc == null) return;
        if (action == 0) {
            svc.injectTap(x, y);
        }
    }

    private static void injectSwipeA11y(float x1, float y1, float x2, float y2, int dur) {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.N) return;
        RemoteAccessibilityService svc = RemoteAccessibilityService.getInstance();
        if (svc == null) return;
        svc.injectSwipe(x1, y1, x2, y2, Math.max(100, dur));
    }

    public static synchronized void destroy() {
        closeRootShell();
        rootAvailable = null;
        rootInitStarted = false;
    }
}
