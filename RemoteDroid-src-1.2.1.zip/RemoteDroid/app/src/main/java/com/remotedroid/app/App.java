package com.remotedroid.app;

import android.app.Application;

import com.remotedroid.app.util.CrashHandler;

import java.io.File;

public class App extends Application {
    @Override
    public void onCreate() {
        super.onCreate();
        try {
            File dir = getExternalFilesDir(null);
            String logPath;
            if (dir != null) {
                logPath = new File(dir, "logs").getAbsolutePath();
            } else {
                logPath = getDir("logs", MODE_PRIVATE).getAbsolutePath();
            }
            CrashHandler.init(logPath);
        } catch (Throwable t) {
            // 崩溃处理器初始化失败不应导致应用无法启动
        }
    }
}
