package com.remotedroid.app.ui;

import android.content.Intent;
import android.media.projection.MediaProjectionManager;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.CheckBox;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import com.google.android.material.button.MaterialButton;
import com.google.android.material.textfield.TextInputEditText;
import com.remotedroid.app.R;
import com.remotedroid.app.service.RemoteAccessibilityService;
import com.remotedroid.app.service.ScreenCastService;
import com.remotedroid.app.util.NetUtil;
import com.remotedroid.app.util.TouchInjector;

public class HostFragment extends Fragment {

    private static final int REQUEST_MEDIA_PROJECTION = 1001;

    private View statusDot;
    private TextView tvStatus;
    private TextView tvIpInfo;
    private TextInputEditText etHostPort;
    private CheckBox cbRoot;
    private CheckBox cbAccessibility;
    private MaterialButton btnEnableAccessibility;
    private TextView tvAccessibilityHint;
    private MaterialButton btnToggleCast;

    private boolean isCasting = false;
    private int chosenPort = 8888;
    private MediaProjectionManager projectionManager;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container,
                             @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_host, container, false);

        statusDot = view.findViewById(R.id.status_dot);
        tvStatus = view.findViewById(R.id.tv_status);
        tvIpInfo = view.findViewById(R.id.tv_ip_info);
        etHostPort = view.findViewById(R.id.et_host_port);
        cbRoot = view.findViewById(R.id.cb_root);
        cbAccessibility = view.findViewById(R.id.cb_accessibility);
        btnEnableAccessibility = view.findViewById(R.id.btn_enable_accessibility);
        tvAccessibilityHint = view.findViewById(R.id.tv_accessibility_hint);
        btnToggleCast = view.findViewById(R.id.btn_toggle_cast);

        projectionManager = (MediaProjectionManager) requireActivity()
                .getSystemService(android.content.Context.MEDIA_PROJECTION_SERVICE);

        // Root检测
        cbRoot.setEnabled(false);
        cbRoot.setText("Root 模式（检测中…）");
        new Thread(() -> {
            final boolean root = TouchInjector.isRootAvailable();
            if (getActivity() == null) return;
            getActivity().runOnUiThread(() -> {
                if (root) {
                    cbRoot.setEnabled(true);
                    cbRoot.setText(getString(R.string.root_mode));
                } else {
                    cbRoot.setEnabled(false);
                    cbRoot.setText("Root 模式（未检测到Root）");
                }
            });
        }, "Root-Check").start();

        // 启动前就显示同WiFi IP
        showLocalIp();
        updateAccessibilityStatus();

        btnEnableAccessibility.setOnClickListener(v ->
                startActivity(new Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)));

        btnToggleCast.setOnClickListener(v -> {
            if (isCasting) stopCast();
            else startCast();
        });

        return view;
    }

    private void showLocalIp() {
        String ip = NetUtil.getWifiIpAddress(requireContext());
        tvIpInfo.setText("本机同WiFi IP: " + ip);
    }

    @Override
    public void onResume() {
        super.onResume();
        updateAccessibilityStatus();
        showLocalIp();
    }

    private void updateAccessibilityStatus() {
        if (RemoteAccessibilityService.isEnabled()) {
            tvAccessibilityHint.setText("无障碍服务已开启，触摸控制可用");
            tvAccessibilityHint.setTextColor(getResources().getColor(R.color.md_success));
        } else {
            tvAccessibilityHint.setText(R.string.accessibility_not_enabled);
            tvAccessibilityHint.setTextColor(getResources().getColor(R.color.md_warning));
        }
    }

    private void startCast() {
        boolean useRoot = cbRoot.isChecked();
        boolean useAccessibility = cbAccessibility.isChecked();
        if (!useRoot && !useAccessibility) {
            Toast.makeText(requireContext(), "请至少选择一种注入模式", Toast.LENGTH_LONG).show();
            return;
        }

        chosenPort = 8888;
        if (etHostPort.getText() != null) {
            String p = etHostPort.getText().toString().trim();
            try {
                int parsed = Integer.parseInt(p);
                if (parsed > 0 && parsed <= 65535) chosenPort = parsed;
            } catch (NumberFormatException ignore) {}
        }

        Intent intent = projectionManager.createScreenCaptureIntent();
        startActivityForResult(intent, REQUEST_MEDIA_PROJECTION);
    }

    @Override
    public void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == REQUEST_MEDIA_PROJECTION
                && resultCode == requireActivity().RESULT_OK && data != null) {
            Intent serviceIntent = new Intent(requireContext(), ScreenCastService.class);
            serviceIntent.putExtra(ScreenCastService.EXTRA_RESULT_CODE, resultCode);
            serviceIntent.putExtra(ScreenCastService.EXTRA_RESULT_DATA, data);
            serviceIntent.putExtra(ScreenCastService.EXTRA_USE_ROOT, cbRoot.isChecked());
            serviceIntent.putExtra(ScreenCastService.EXTRA_PORT, chosenPort);

            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                requireActivity().startForegroundService(serviceIntent);
            } else {
                requireActivity().startService(serviceIntent);
            }

            isCasting = true;
            updateUI();
            Toast.makeText(requireContext(), "服务已启动", Toast.LENGTH_SHORT).show();
        } else {
            Toast.makeText(requireContext(), "未授予屏幕录制权限", Toast.LENGTH_SHORT).show();
        }
    }

    private void stopCast() {
        requireActivity().stopService(new Intent(requireContext(), ScreenCastService.class));
        isCasting = false;
        updateUI();
        Toast.makeText(requireContext(), "服务已停止", Toast.LENGTH_SHORT).show();
    }

    private void updateUI() {
        if (isCasting) {
            statusDot.setBackgroundResource(R.drawable.circle_green);
            tvStatus.setText(R.string.status_casting);
            tvStatus.setTextColor(getResources().getColor(R.color.md_success));
            btnToggleCast.setText(R.string.stop_service);
            btnToggleCast.setBackgroundTintList(
                    android.content.res.ColorStateList.valueOf(getResources().getColor(R.color.md_error)));
            etHostPort.setEnabled(false);
            cbRoot.setEnabled(false);
            cbAccessibility.setEnabled(false);
            String ip = NetUtil.getWifiIpAddress(requireContext());
            tvIpInfo.setText("本机IP: " + ip + "    端口: " + chosenPort);
        } else {
            statusDot.setBackgroundResource(R.drawable.circle_grey);
            tvStatus.setText(R.string.status_disconnected);
            tvStatus.setTextColor(getResources().getColor(R.color.md_text_secondary));
            btnToggleCast.setText(R.string.start_service);
            btnToggleCast.setBackgroundTintList(
                    android.content.res.ColorStateList.valueOf(getResources().getColor(R.color.md_primary)));
            etHostPort.setEnabled(true);
            cbRoot.setEnabled(true);
            cbAccessibility.setEnabled(true);
            showLocalIp();
        }
    }
}
