package com.remotedroid.app.ui;

import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.util.Log;
import android.view.MotionEvent;
import android.view.Surface;
import android.view.SurfaceHolder;
import android.view.SurfaceView;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.google.android.material.button.MaterialButton;
import com.remotedroid.app.R;
import com.remotedroid.app.net.VideoStreamClient;
import com.remotedroid.app.service.AudioPlayer;
import com.remotedroid.app.service.H264Decoder;

import java.util.concurrent.atomic.AtomicBoolean;

/**
 * 远程控制画面。
 *
 * 稳定性说明（v1.2.1）：
 * - 解码器的启动/停止/重建全部收敛到主线程，与Surface生命周期严格串行，避免竞态崩溃；
 * - Surface销毁时立即停掉解码器，不会向已销毁的Surface送帧；
 * - 收到新的 SPS/PPS 或编码分辨率变化时自动重建解码器（配合被控端动态改分辨率）；
 * - 所有回调均有异常兜底，任何网络回调异常都不会闪退。
 */
public class RemoteActivity extends AppCompatActivity {

    private static final String TAG = "RemoteActivity";
    public static final String EXTRA_HOST = "host";
    public static final String EXTRA_PORT = "port";
    public static final String EXTRA_RESOLUTION = "resolution";
    public static final String EXTRA_BITRATE = "bitrate";

    private SurfaceView surfaceView;
    private ProgressBar progressLoading;
    private TextView tvStatus;
    private MaterialButton btnDisconnect;

    private VideoStreamClient client;
    private H264Decoder decoder;
    private AudioPlayer audioPlayer;
    private String host;
    private int port;
    private int resolutionMode = 1080;
    private int bitrateMode = 1;

    // 被控端物理分辨率（用于触摸映射） / 实际编码分辨率（用于解码器尺寸提示）
    private volatile int remoteWidth = 0;
    private volatile int remoteHeight = 0;
    private volatile int encodeWidth = 0;
    private volatile int encodeHeight = 0;
    private volatile byte[] codecConfig = null;

    private final Handler mainHandler = new Handler(Looper.getMainLooper());
    private final AtomicBoolean finishing = new AtomicBoolean(false);
    private final AtomicBoolean decoderStarted = new AtomicBoolean(false);
    private volatile boolean surfaceReady = false;
    private int decoderWidth = 0;
    private int decoderHeight = 0;
    private byte[] decoderConfig = null;
    private int startRetries = 0;
    private final Runnable restartRunnable = new Runnable() {
        @Override
        public void run() {
            if (!finishing.get()) tryStartDecoder();
        }
    };

    private float viewToRemoteX = 1.0f;
    private float viewToRemoteY = 1.0f;

    // 手势追踪
    private float downX, downY;
    private long downTime;
    private boolean gestureActive = false;
    private static final float TAP_SLOP = 24f;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        try {
            getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        } catch (Throwable ignore) {}
        setContentView(R.layout.activity_remote);

        host = getIntent().getStringExtra(EXTRA_HOST);
        port = getIntSafe(getIntent(), EXTRA_PORT, 8888);
        resolutionMode = getIntSafe(getIntent(), EXTRA_RESOLUTION, 1080);
        bitrateMode = getIntSafe(getIntent(), EXTRA_BITRATE, 1);

        if (host == null || host.trim().isEmpty()) {
            safeToast("无效的IP地址");
            finish();
            return;
        }

        surfaceView = findViewById(R.id.surface_view);
        progressLoading = findViewById(R.id.progress_loading);
        tvStatus = findViewById(R.id.tv_remote_status);
        btnDisconnect = findViewById(R.id.btn_disconnect);

        TextView tvTitle = findViewById(R.id.tv_remote_title);
        tvTitle.setText(host);

        btnDisconnect.setOnClickListener(v -> disconnect());

        surfaceView.getHolder().addCallback(new SurfaceHolder.Callback() {
            @Override
            public void surfaceCreated(SurfaceHolder holder) {
                surfaceReady = true;
                mainHandler.post(RemoteActivity.this::tryStartDecoder);
            }

            @Override
            public void surfaceChanged(SurfaceHolder holder, int format, int width, int height) {
                updateMapping(width, height);
            }

            @Override
            public void surfaceDestroyed(SurfaceHolder holder) {
                surfaceReady = false;
                // 立即停掉解码器，避免向已销毁的Surface继续送帧
                mainHandler.post(RemoteActivity.this::stopDecoderInternal);
            }
        });

        surfaceView.setOnTouchListener(this::handleTouch);
        connect();
    }

    private static int getIntSafe(android.content.Intent i, String key, int def) {
        try { return i.getIntExtra(key, def); } catch (Exception e) { return def; }
    }

    private void updateMapping(int viewWidth, int viewHeight) {
        if (remoteWidth > 0 && remoteHeight > 0 && viewWidth > 0 && viewHeight > 0) {
            viewToRemoteX = (float) remoteWidth / viewWidth;
            viewToRemoteY = (float) remoteHeight / viewHeight;
        }
    }

    /**
     * 手势识别：DOWN记录起点，UP时判断点击还是滑动，发送完整手势。
     * 整体try/catch，保证触摸永不导致崩溃或退出。
     */
    private boolean handleTouch(View v, MotionEvent event) {
        try {
            VideoStreamClient c = client;
            if (c == null || !c.isConnected()) return true;

            switch (event.getActionMasked()) {
                case MotionEvent.ACTION_DOWN:
                    downX = event.getX() * viewToRemoteX;
                    downY = event.getY() * viewToRemoteY;
                    downTime = System.currentTimeMillis();
                    gestureActive = true;
                    return true;

                case MotionEvent.ACTION_UP:
                    if (!gestureActive) return true;
                    float upX = event.getX() * viewToRemoteX;
                    float upY = event.getY() * viewToRemoteY;
                    long duration = System.currentTimeMillis() - downTime;
                    float dx = Math.abs(upX - downX);
                    float dy = Math.abs(upY - downY);

                    if (dx < TAP_SLOP && dy < TAP_SLOP && duration < 800) {
                        c.sendTouchEvent(0, upX, upY, 0);
                    } else {
                        int swipeDuration = (int) Math.max(150, Math.min(duration, 1000));
                        c.sendSwipeEvent(downX, downY, upX, upY, swipeDuration);
                    }
                    gestureActive = false;
                    return true;

                case MotionEvent.ACTION_CANCEL:
                    gestureActive = false;
                    return true;
            }
        } catch (Throwable t) {
            Log.w(TAG, "touch handling error (ignored)", t);
            gestureActive = false;
        }
        return true;
    }

    private void connect() {
        tvStatus.setText("连接中…");
        progressLoading.setVisibility(View.VISIBLE);

        client = new VideoStreamClient(host, port);
        client.setOnConnectionListener(new VideoStreamClient.OnConnectionListener() {
            @Override
            public void onConnected() {
                runOnUiThreadSafe(() -> {
                    tvStatus.setText("已连接，等待画面…");
                    tvStatus.setTextColor(0xFF00C853);
                    ensureAudio();
                    VideoStreamClient c = client;
                    if (c != null) {
                        c.sendConfig(resolutionMode, bitrateMode);
                    }
                });
            }

            @Override
            public void onDisconnected(String reason) {
                runOnUiThreadSafe(() -> {
                    tvStatus.setText("已断开");
                    tvStatus.setTextColor(0xFFFF5252);
                    progressLoading.setVisibility(View.GONE);
                });
            }

            @Override
            public void onError(String error) {
                runOnUiThreadSafe(() -> {
                    tvStatus.setText("连接失败");
                    tvStatus.setTextColor(0xFFFF5252);
                    progressLoading.setVisibility(View.GONE);
                    safeToast("连接失败，请检查IP和网络");
                });
            }
        });

        client.setOnFrameListener(new VideoStreamClient.OnFrameListener() {
            @Override
            public void onVideoFrame(byte[] data, long presentationTimeUs) {
                H264Decoder d = decoder;
                if (d != null && decoderStarted.get()) {
                    try {
                        d.decodeFrame(data, presentationTimeUs);
                    } catch (Throwable t) {
                        Log.w(TAG, "decode frame error (ignored)", t);
                    }
                }
            }

            @Override
            public void onScreenInfo(int width, int height) {
                remoteWidth = width;
                remoteHeight = height;
                runOnUiThreadSafe(() -> {
                    adjustSurfaceAspect();
                    progressLoading.setVisibility(View.GONE);
                });
                scheduleDecoderRestart();
            }

            @Override
            public void onEncodeInfo(int width, int height) {
                encodeWidth = width;
                encodeHeight = height;
                scheduleDecoderRestart();
            }

            @Override
            public void onCodecConfig(byte[] config) {
                codecConfig = config;
                H264Decoder d = decoder;
                if (d != null) {
                    try { d.setCodecConfig(config); } catch (Throwable ignore) {}
                }
                scheduleDecoderRestart();
            }

            @Override
            public void onAudioFrame(byte[] data, int length) {
                try {
                    AudioPlayer p = audioPlayer;
                    if (p != null) p.play(data, length);
                } catch (Throwable ignore) {}
            }
        });

        client.connect();
    }

    private void ensureAudio() {
        if (audioPlayer != null) return;
        try {
            AudioPlayer p = new AudioPlayer();
            p.start();
            audioPlayer = p;
        } catch (Throwable t) {
            Log.w(TAG, "audio init failed (ignored)", t);
            audioPlayer = null;
        }
    }

    private void runOnUiThreadSafe(Runnable r) {
        if (finishing.get() || isFinishing()) return;
        runOnUiThread(() -> {
            try {
                r.run();
            } catch (Throwable t) {
                Log.w(TAG, "ui task error (ignored)", t);
            }
        });
    }

    private void safeToast(String text) {
        try {
            if (!isFinishing() && !isDestroyed()) {
                Toast.makeText(this, text, Toast.LENGTH_SHORT).show();
            }
        } catch (Throwable ignore) {}
    }

    private void adjustSurfaceAspect() {
        if (remoteWidth <= 0 || remoteHeight <= 0) return;
        try {
            surfaceView.post(() -> {
                try {
                    ViewGroup.LayoutParams params = surfaceView.getLayoutParams();
                    if (params == null) return;
                    int viewWidth = surfaceView.getWidth();
                    int viewHeight = surfaceView.getHeight();
                    if (viewWidth == 0 || viewHeight == 0) return;

                    float viewAspect = (float) viewWidth / viewHeight;
                    float remoteAspect = (float) remoteWidth / remoteHeight;

                    if (viewAspect > remoteAspect) {
                        params.width = Math.round(viewHeight * remoteAspect);
                        params.height = viewHeight;
                    } else {
                        params.width = viewWidth;
                        params.height = Math.round(viewWidth / remoteAspect);
                    }
                    surfaceView.setLayoutParams(params);
                    updateMapping(params.width, params.height);
                } catch (Throwable t) {
                    Log.w(TAG, "adjust aspect error (ignored)", t);
                }
            });
        } catch (Throwable t) {
            Log.w(TAG, "adjust aspect post error (ignored)", t);
        }
    }

    /** 稍微延后重建解码器，把同一批到达的 config/尺寸变化合并成一次重建 */
    private void scheduleDecoderRestart() {
        if (finishing.get()) return;
        mainHandler.removeCallbacks(restartRunnable);
        mainHandler.postDelayed(restartRunnable, 150);
    }

    /** 主线程调用：按当前状态启动解码器（已在运行且参数未变则跳过） */
    private void tryStartDecoder() {
        try {
            if (finishing.get() || !surfaceReady) return;
            if (remoteWidth <= 0 || remoteHeight <= 0) return;
            int w = encodeWidth > 0 ? encodeWidth : remoteWidth;
            int h = encodeHeight > 0 ? encodeHeight : remoteHeight;
            byte[] cfg = codecConfig;
            if (decoderStarted.get() && decoder != null
                    && w == decoderWidth && h == decoderHeight && cfg == decoderConfig) {
                return;
            }
            startDecoder(w, h);
        } catch (Throwable t) {
            Log.w(TAG, "tryStartDecoder error (ignored)", t);
        }
    }

    /** 主线程调用 */
    private void startDecoder(int w, int h) {
        stopDecoderInternal();
        Surface surface = null;
        try {
            surface = surfaceView.getHolder().getSurface();
        } catch (Throwable ignore) {}
        if (surface == null || !surface.isValid()) {
            return;
        }
        try {
            H264Decoder d = new H264Decoder(surface, w, h);
            byte[] cfg = codecConfig;
            if (cfg != null) {
                d.setCodecConfig(cfg);
            }
            d.start();
            decoder = d;
            decoderStarted.set(true);
            decoderWidth = w;
            decoderHeight = h;
            decoderConfig = cfg;
            startRetries = 0;
            Log.i(TAG, "Decoder started for " + w + "x" + h);
        } catch (Throwable t) {
            Log.e(TAG, "Failed to start decoder", t);
            decoder = null;
            decoderStarted.set(false);
            // 暂时失败时稍后重试（最多5次），避免偶发问题导致一直黑屏
            if (startRetries < 5) {
                startRetries++;
                mainHandler.postDelayed(restartRunnable, 500);
            }
        }
    }

    /** 主线程调用 */
    private void stopDecoderInternal() {
        H264Decoder d = decoder;
        decoder = null;
        decoderStarted.set(false);
        decoderWidth = 0;
        decoderHeight = 0;
        decoderConfig = null;
        if (d != null) {
            try { d.stop(); } catch (Throwable ignore) {}
        }
    }

    private void disconnect() {
        if (finishing.getAndSet(true)) return;
        try { if (client != null) client.disconnect(); } catch (Throwable ignore) {}
        client = null;
        mainHandler.removeCallbacksAndMessages(null);
        stopDecoderInternal();
        if (audioPlayer != null) {
            try { audioPlayer.stop(); } catch (Throwable ignore) {}
            audioPlayer = null;
        }
        finish();
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        try {
            mainHandler.removeCallbacksAndMessages(null);
            if (client != null) client.disconnect();
            client = null;
            stopDecoderInternal();
            if (audioPlayer != null) {
                audioPlayer.stop();
                audioPlayer = null;
            }
        } catch (Throwable t) {
            Log.w(TAG, "onDestroy cleanup error (ignored)", t);
        }
    }

    @Override
    public void onBackPressed() {
        // 返回键同样走断开流程（属于主动操作）
        disconnect();
    }
}
