package com.remotedroid.app.ui;

import android.content.Intent;
import android.os.Bundle;
import android.text.method.DigitsKeyListener;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.AutoCompleteTextView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.google.android.material.button.MaterialButton;
import com.google.android.material.textfield.TextInputEditText;
import com.remotedroid.app.R;
import com.remotedroid.app.net.UdpDiscovery;

import java.util.ArrayList;
import java.util.List;

public class ControlFragment extends Fragment {

    private TextInputEditText etIp;
    private TextInputEditText etPort;
    private AutoCompleteTextView actvResolution;
    private AutoCompleteTextView actvBitrate;
    private MaterialButton btnConnect;
    private MaterialButton btnScan;
    private RecyclerView rvDevices;
    private TextView tvEmpty;
    private DeviceAdapter adapter;
    private UdpDiscovery udpDiscovery;
    private List<UdpDiscovery.DeviceInfo> deviceList = new ArrayList<>();

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container,
                             @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_control, container, false);

        etIp = view.findViewById(R.id.et_ip);
        etPort = view.findViewById(R.id.et_port);
        actvResolution = view.findViewById(R.id.actv_resolution);
        actvBitrate = view.findViewById(R.id.actv_bitrate);
        etIp.setKeyListener(DigitsKeyListener.getInstance("0123456789."));

        // 初始化分辨率选项
        String[] resolutions = {"720P (流畅)", "1080P (默认)", "2K (超清)"};
        ArrayAdapter<String> resAdapter = new ArrayAdapter<>(requireContext(),
                android.R.layout.simple_list_item_1, resolutions);
        actvResolution.setAdapter(resAdapter);
        actvResolution.setText(resolutions[1], false); // 默认1080P

        // 初始化码率选项
        String[] bitrates = {"低 (默认省流)", "中 (均衡)", "高 (超清)"};
        ArrayAdapter<String> brAdapter = new ArrayAdapter<>(requireContext(),
                android.R.layout.simple_list_item_1, bitrates);
        actvBitrate.setAdapter(brAdapter);
        actvBitrate.setText(bitrates[0], false); // 默认低码率

        btnConnect = view.findViewById(R.id.btn_connect);
        btnScan = view.findViewById(R.id.btn_scan);
        rvDevices = view.findViewById(R.id.rv_devices);
        tvEmpty = view.findViewById(R.id.tv_empty);

        rvDevices.setLayoutManager(new LinearLayoutManager(requireContext()));
        adapter = new DeviceAdapter(deviceList, device -> connectTo(device.ip, device.port));
        rvDevices.setAdapter(adapter);

        btnConnect.setOnClickListener(v -> {
            String ip = etIp.getText() != null ? etIp.getText().toString().trim() : "";
            String portStr = etPort.getText() != null ? etPort.getText().toString().trim() : "8888";
            if (ip.isEmpty()) {
                Toast.makeText(requireContext(), "请输入IP地址", Toast.LENGTH_SHORT).show();
                return;
            }
            int port = 8888;
            try {
                port = Integer.parseInt(portStr);
            } catch (NumberFormatException e) {
                port = 8888;
            }
            connectTo(ip, port);
        });

        btnScan.setOnClickListener(v -> startDiscovery());
        startDiscovery();

        return view;
    }

    private void startDiscovery() {
        if (udpDiscovery != null) udpDiscovery.stop();
        deviceList.clear();
        adapter.notifyDataSetChanged();
        tvEmpty.setVisibility(View.VISIBLE);

        udpDiscovery = new UdpDiscovery(requireContext());
        udpDiscovery.setOnDeviceFoundListener(new UdpDiscovery.OnDeviceFoundListener() {
            @Override
            public void onDeviceFound(UdpDiscovery.DeviceInfo device) {
                requireActivity().runOnUiThread(() -> {
                    boolean exists = false;
                    for (UdpDiscovery.DeviceInfo d : deviceList) {
                        if (d.ip.equals(device.ip)) {
                            exists = true;
                            break;
                        }
                    }
                    if (!exists) {
                        deviceList.add(device);
                        adapter.notifyDataSetChanged();
                        tvEmpty.setVisibility(View.GONE);
                    }
                });
            }

            @Override
            public void onDeviceListChanged(List<UdpDiscovery.DeviceInfo> devices) {}
        });
        udpDiscovery.start();
        Toast.makeText(requireContext(), "正在扫描同一WiFi下的设备…", Toast.LENGTH_SHORT).show();
    }

    private void connectTo(String ip, int port) {
        if (udpDiscovery != null) udpDiscovery.stop();
        // 解析用户选择
        String resSel = actvResolution.getText().toString();
        int resMode;
        if (resSel.startsWith("720")) resMode = 720;
        else if (resSel.startsWith("2K") || resSel.startsWith("1440")) resMode = 1440;
        else resMode = 1080;

        String brSel = actvBitrate.getText().toString();
        int brMode;
        if (brSel.startsWith("中")) brMode = 2;
        else if (brSel.startsWith("高")) brMode = 3;
        else brMode = 1;

        Intent intent = new Intent(requireContext(), RemoteActivity.class);
        intent.putExtra(RemoteActivity.EXTRA_HOST, ip);
        intent.putExtra(RemoteActivity.EXTRA_PORT, port);
        intent.putExtra(RemoteActivity.EXTRA_RESOLUTION, resMode);
        intent.putExtra(RemoteActivity.EXTRA_BITRATE, brMode);
        startActivity(intent);
    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();
        if (udpDiscovery != null) udpDiscovery.stop();
    }
}
