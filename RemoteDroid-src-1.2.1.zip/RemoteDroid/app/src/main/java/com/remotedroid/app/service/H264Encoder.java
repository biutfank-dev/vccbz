package com.remotedroid.app.service;

import android.media.MediaCodec;
import android.media.MediaCodecInfo;
import android.media.MediaCodecList;
import android.media.MediaFormat;
import android.util.Log;
import android.view.Surface;

import java.io.IOException;
import java.nio.ByteBuffer;
import java.util.concurrent.atomic.AtomicBoolean;

public class H264Encoder {

    private static final String TAG = "H264Encoder";
    private static final String MIME_TYPE = "video/avc";

    private MediaCodec codec;
    private Surface inputSurface;
    private AtomicBoolean running = new AtomicBoolean(false);
    private Thread outputThread;
    private OnEncodedFrameListener listener;
    private int width;
    private int height;
    private int bitrate;
    private int frameRate;
    private long frameCount = 0;
    private byte[] codecConfigData = null;

    public interface OnEncodedFrameListener {
        void onEncodedFrame(byte[] data, long presentationTimeUs, int flags);
    }

    public H264Encoder(int width, int height, int bitrate, int frameRate) {
        this.width = width;
        this.height = height;
        this.bitrate = bitrate;
        this.frameRate = frameRate;
    }

    public Surface getInputSurface() {
        return inputSurface;
    }

    public byte[] getCodecConfigData() {
        return codecConfigData;
    }

    public void setOnEncodedFrameListener(OnEncodedFrameListener listener) {
        this.listener = listener;
    }

    public void start() throws IOException {
        MediaFormat format = MediaFormat.createVideoFormat(MIME_TYPE, width, height);
        format.setInteger(MediaFormat.KEY_COLOR_FORMAT,
                MediaCodecInfo.CodecCapabilities.COLOR_FormatSurface);
        format.setInteger(MediaFormat.KEY_BIT_RATE, bitrate);
        format.setInteger(MediaFormat.KEY_FRAME_RATE, frameRate);
        format.setInteger(MediaFormat.KEY_I_FRAME_INTERVAL, 1); // 每秒1个I帧，丢包后快速恢复
        // 低延迟实时编码参数
        format.setInteger(MediaFormat.KEY_BITRATE_MODE,
                MediaCodecInfo.EncoderCapabilities.BITRATE_MODE_CBR); // 固定码率，避免波动
        try {
            format.setInteger(MediaFormat.KEY_MAX_B_FRAMES, 0); // 无B帧，降低延迟
            format.setInteger(MediaFormat.KEY_PRIORITY, 0); // 实时编码最高优先级
            format.setLong(MediaFormat.KEY_REPEAT_PREVIOUS_FRAME_AFTER, 100_000); // 静态画面100ms重复帧，防止卡顿
        } catch (Exception ignore) {}

        // 尝试查询编码器能力，选择最兼容的配置
        MediaCodecInfo codecInfo = selectCodec(MIME_TYPE);
        if (codecInfo != null) {
            try {
                MediaCodecInfo.CodecCapabilities caps =
                        codecInfo.getCapabilitiesForType(MIME_TYPE);
                MediaCodecInfo.VideoCapabilities vc = caps.getVideoCapabilities();
                if (vc != null) {
                    // 确保尺寸在支持范围内
                    if (!vc.isSizeSupported(width, height)) {
                        // 找一个支持的尺寸
                        width = vc.getSupportedWidths().getUpper();
                        height = vc.getSupportedHeightsFor(width).getUpper();
                        Log.w(TAG, "Adjusted to supported size: " + width + "x" + height);
                    }
                    // 确保码率在支持范围内
                    int maxBr = vc.getBitrateRange().getUpper();
                    int minBr = vc.getBitrateRange().getLower();
                    bitrate = Math.max(minBr, Math.min(bitrate, maxBr));
                    format.setInteger(MediaFormat.KEY_BIT_RATE, bitrate);
                }
            } catch (Exception e) {
                Log.w(TAG, "Failed to query codec capabilities", e);
            }
        }

        try {
            if (codecInfo != null) {
                codec = MediaCodec.createByCodecName(codecInfo.getName());
            } else {
                codec = MediaCodec.createEncoderByType(MIME_TYPE);
            }
            codec.configure(format, null, null, MediaCodec.CONFIGURE_FLAG_ENCODE);
            inputSurface = codec.createInputSurface();
            codec.start();
            running.set(true);
            outputThread = new Thread(this::outputLoop, "H264-Encoder");
            outputThread.start();
            Log.i(TAG, "Encoder started: " + width + "x" + height
                    + " bitrate=" + bitrate + " fps=" + frameRate);
        } catch (IOException e) {
            releaseCodec();
            throw e;
        } catch (IllegalStateException e) {
            Log.e(TAG, "Codec configure failed, trying with lower settings", e);
            releaseCodec();
            // 降级重试
            try {
                width = align16(width / 2);
                height = align16(height / 2);
                bitrate = Math.min(bitrate / 2, 2_000_000);
                MediaFormat fallback = MediaFormat.createVideoFormat(MIME_TYPE, width, height);
                fallback.setInteger(MediaFormat.KEY_COLOR_FORMAT,
                        MediaCodecInfo.CodecCapabilities.COLOR_FormatSurface);
                fallback.setInteger(MediaFormat.KEY_BIT_RATE, bitrate);
                fallback.setInteger(MediaFormat.KEY_FRAME_RATE, 15);
                fallback.setInteger(MediaFormat.KEY_I_FRAME_INTERVAL, 2);
                codec = MediaCodec.createEncoderByType(MIME_TYPE);
                codec.configure(fallback, null, null, MediaCodec.CONFIGURE_FLAG_ENCODE);
                inputSurface = codec.createInputSurface();
                codec.start();
                running.set(true);
                outputThread = new Thread(this::outputLoop, "H264-Encoder-Fallback");
                outputThread.start();
                Log.w(TAG, "Fallback encoder: " + width + "x" + height);
            } catch (Exception e2) {
                releaseCodec();
                throw new IOException("Encoder failed even with fallback", e2);
            }
        }
    }

    private void outputLoop() {
        MediaCodec.BufferInfo bufferInfo = new MediaCodec.BufferInfo();
        while (running.get()) {
            MediaCodec c = codec;
            if (c == null) break;
            try {
                int outputBufferId = c.dequeueOutputBuffer(bufferInfo, 10000);
                if (outputBufferId >= 0) {
                    ByteBuffer outputBuffer = c.getOutputBuffer(outputBufferId);
                    if (outputBuffer != null && bufferInfo.size > 0) {
                        byte[] data = new byte[bufferInfo.size];
                        outputBuffer.get(data);
                        frameCount++;
                        // 缓存SPS/PPS配置帧
                        if ((bufferInfo.flags & MediaCodec.BUFFER_FLAG_CODEC_CONFIG) != 0) {
                            codecConfigData = data;
                            Log.i(TAG, "Cached codec config, size=" + data.length);
                        }
                        if (frameCount % 30 == 1) {
                            Log.i(TAG, "encoded frame#" + frameCount + " size="
                                    + bufferInfo.size + " flags=" + bufferInfo.flags);
                        }
                        try {
                            if (listener != null) {
                                listener.onEncodedFrame(data, bufferInfo.presentationTimeUs, bufferInfo.flags);
                            }
                        } catch (Throwable t) {
                            Log.w(TAG, "frame listener error", t);
                        }
                    }
                    c.releaseOutputBuffer(outputBufferId, false);
                } else if (outputBufferId == MediaCodec.INFO_OUTPUT_FORMAT_CHANGED) {
                    MediaFormat newFormat = c.getOutputFormat();
                    Log.i(TAG, "Encoder output format: " + newFormat);
                    // 从format提取SPS/PPS（部分机型这里返回）
                    try {
                        ByteBuffer sps = newFormat.getByteBuffer("csd-0");
                        ByteBuffer pps = newFormat.getByteBuffer("csd-1");
                        if (sps != null && pps != null) {
                            byte[] spsArr = new byte[sps.remaining()];
                            sps.get(spsArr);
                            byte[] ppsArr = new byte[pps.remaining()];
                            pps.get(ppsArr);
                            byte[] combined = new byte[spsArr.length + ppsArr.length];
                            System.arraycopy(spsArr, 0, combined, 0, spsArr.length);
                            System.arraycopy(ppsArr, 0, combined, spsArr.length, ppsArr.length);
                            codecConfigData = combined;
                            Log.i(TAG, "Extracted SPS/PPS from format, size=" + combined.length);
                        }
                    } catch (Throwable e) {
                        Log.w(TAG, "Failed to extract csd", e);
                    }
                }
                // INFO_TRY_AGAIN_LATER 和 INFO_OUTPUT_BUFFERS_CHANGED 忽略
            } catch (MediaCodec.CodecException e) {
                Log.e(TAG, "CodecException in encoder, recovering", e);
                if (!running.get()) break;
            } catch (IllegalStateException e) {
                if (running.get()) Log.e(TAG, "Encoder state error", e);
                break;
            } catch (Throwable e) {
                if (running.get()) Log.e(TAG, "Encoder output error", e);
                break;
            }
        }
    }

    private static MediaCodecInfo selectCodec(String mimeType) {
        try {
            MediaCodecList codecList = new MediaCodecList(MediaCodecList.REGULAR_CODECS);
            MediaCodecInfo[] allCodecs = codecList.getCodecInfos();
            MediaCodecInfo selected = null;
            for (MediaCodecInfo codecInfo : allCodecs) {
                if (codecInfo == null || !codecInfo.isEncoder()) continue;
                String[] types = codecInfo.getSupportedTypes();
                for (String t : types) {
                    if (t.equalsIgnoreCase(mimeType)) {
                        String name = codecInfo.getName();
                        if (name.startsWith("c2.android") || name.startsWith("OMX.")) {
                            return codecInfo;
                        }
                        if (selected == null) selected = codecInfo;
                    }
                }
            }
            return selected;
        } catch (Exception e) {
            Log.w(TAG, "selectCodec failed", e);
            return null;
        }
    }

    private static int align16(int v) {
        return Math.max(16, (v + 15) / 16 * 16);
    }

    private void releaseCodec() {
        if (codec != null) {
            try { codec.release(); } catch (Exception e) { e.printStackTrace(); }
            codec = null;
        }
        if (inputSurface != null) {
            try { inputSurface.release(); } catch (Exception e) { e.printStackTrace(); }
            inputSurface = null;
        }
    }

    public void stop() {
        running.set(false);
        // 先stop唤醒可能阻塞在dequeue的编码线程，再join，最后才释放，
        // 避免旧线程还在使用codec时就被release导致偶发原生崩溃。
        MediaCodec c = codec;
        if (c != null) {
            try { c.stop(); } catch (Throwable ignore) {}
        }
        if (outputThread != null) {
            try { outputThread.join(1000); } catch (InterruptedException e) { Thread.currentThread().interrupt(); }
            outputThread = null;
        }
        releaseCodec();
        Log.i(TAG, "Encoder stopped");
    }
}
