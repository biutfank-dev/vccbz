package com.remotedroid.app.util;

import android.app.Activity;
import android.os.Handler;
import android.os.Looper;
import android.text.Html;
import android.util.Log;

import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.Charset;
import java.util.regex.Pattern;

/**
 * 远程公告：发起HTTP请求，从“响应体”中截取纯文本内容（不是展示一个HTML网页）。
 *
 * 使用方式：把下面 ANNOUNCEMENT_URL 改成你自己的公告地址（.txt 或 .html 均可）。
 * 响应体可以是纯文本，也可以是HTML——HTML会被去掉标签、只保留可见文字。
 * 拉取失败或内容为空时不弹窗。
 */
public class AnnouncementFetcher {

    private static final String TAG = "Announcement";

    // 远程公告地址
    public static String ANNOUNCEMENT_URL = "http://jijie886.3vfree.vip/";

    public interface Callback {
        void onResult(String plainText);
    }

    public static void fetch(final Callback cb) {
        new Thread(() -> {
            String text = null;
            HttpURLConnection conn = null;
            try {
                URL u = new URL(ANNOUNCEMENT_URL);
                conn = (HttpURLConnection) u.openConnection();
                conn.setRequestMethod("GET");
                conn.setConnectTimeout(8000);
                conn.setReadTimeout(8000);
                conn.setInstanceFollowRedirects(true);
                conn.setRequestProperty("User-Agent", "RemoteDroid/1.3");
                conn.connect();

                int code = conn.getResponseCode();
                if (code < 200 || code >= 300) {
                    Log.w(TAG, "announce http " + code);
                    post(cb, null);
                    return;
                }

                String charset = "UTF-8";
                String ct = conn.getContentType();
                if (ct != null) {
                    for (String part : ct.split(";")) {
                        part = part.trim();
                        if (part.toLowerCase().startsWith("charset=")) {
                            charset = part.substring(8);
                        }
                    }
                }

                InputStream is = conn.getInputStream();
                ByteArrayOutputStream bos = new ByteArrayOutputStream();
                byte[] buf = new byte[4096];
                int n;
                while ((n = is.read(buf)) != -1) {
                    bos.write(buf, 0, n);
                }
                String body = new String(bos.toByteArray(), Charset.forName(charset));
                text = extractText(body);
            } catch (Exception e) {
                Log.w(TAG, "announce fetch failed: " + e.getMessage());
                text = null;
            } finally {
                if (conn != null) conn.disconnect();
            }
            post(cb, text);
        }, "Announcement").start();
    }

    private static void post(final Callback cb, final String text) {
        if (cb == null) return;
        new Handler(Looper.getMainLooper()).post(() -> {
            try { cb.onResult(text); } catch (Exception ignore) {}
        });
    }

    /**
     * 从响应体截取纯文本：
     * 1) 删除 script/style 等非可见块；
     * 2) 用系统Html解析器去掉所有标签并转义实体；
     * 3) 折叠空白。
     */
    public static String extractText(String body) {
        if (body == null) return null;
        String s = body;
        // 删除整段 script/style/noscript
        s = Pattern.compile("(?is)<(script|style|noscript)[^>]*>.*?</\\1>").matcher(s).replaceAll("");
        // 块级标签转换行，避免文字粘连
        s = s.replaceAll("(?i)<br\\s*/?>", "\n");
        s = s.replaceAll("(?i)</(p|div|li|h[1-6]|tr)>", "\n");
        // 系统解析器去标签 + 反转义HTML实体
        android.text.Spanned spanned = Html.fromHtml(s, Html.FROM_HTML_MODE_LEGACY);
        s = spanned.toString();
        // 折叠多余空白（保留换行）
        StringBuilder out = new StringBuilder();
        String[] lines = s.split("\n");
        for (String line : lines) {
            String t = line.replaceAll("[\\t\\x0B\\f\\r ]+", " ").trim();
            if (!t.isEmpty()) out.append(t).append('\n');
        }
        String result = out.toString().trim();
        return result.isEmpty() ? null : result;
    }

    /** 便捷方法：拉取并在Activity上以公告对话框展示 */
    public static void showIfAvailable(final Activity activity) {
        fetch(text -> {
            if (text == null || activity == null || activity.isFinishing()) return;
            try {
                new androidx.appcompat.app.AlertDialog.Builder(activity)
                        .setTitle("公告")
                        .setMessage(text)
                        .setPositiveButton("知道了", null)
                        .setCancelable(true)
                        .show();
            } catch (Exception ignore) {}
        });
    }
}
