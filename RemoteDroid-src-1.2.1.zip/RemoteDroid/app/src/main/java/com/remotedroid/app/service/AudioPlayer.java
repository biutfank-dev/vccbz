package com.remotedroid.app.service;

import android.media.AudioAttributes;
import android.media.AudioFormat;
import android.media.AudioManager;
import android.media.AudioTrack;
import android.util.Log;

/**
 * 控制端音频播放：播放接收到的PCM数据，自动跟随当前输出设备（扬声器/耳机/蓝牙）。
 * 全部操作做了异常兜底，不会因为音频设备异常导致闪退。
 */
public class AudioPlayer {
    private static final String TAG = "AudioPlayer";
    public static final int SAMPLE_RATE = AudioCapture.SAMPLE_RATE;
    public static final int CHANNEL_CONFIG = AudioFormat.CHANNEL_OUT_STEREO;
    public static final int AUDIO_FORMAT = AudioFormat.ENCODING_PCM_16BIT;

    private static final int BUFFER_SIZE = calcBufferSize();

    private AudioTrack audioTrack;
    private volatile boolean started = false;

    private static int calcBufferSize() {
        try {
            int min = AudioTrack.getMinBufferSize(SAMPLE_RATE, CHANNEL_CONFIG, AUDIO_FORMAT);
            if (min > 0) return min * 2;
        } catch (Throwable t) {
            Log.w(TAG, "getMinBufferSize failed", t);
        }
        return 16384; // 兜底
    }

    public synchronized boolean start() {
        if (started) return true;
        try {
            AudioTrack track = new AudioTrack.Builder()
                    .setAudioAttributes(new AudioAttributes.Builder()
                            .setUsage(AudioAttributes.USAGE_MEDIA)
                            .setContentType(AudioAttributes.CONTENT_TYPE_MOVIE)
                            .build())
                    .setAudioFormat(new AudioFormat.Builder()
                            .setEncoding(AUDIO_FORMAT)
                            .setSampleRate(SAMPLE_RATE)
                            .setChannelMask(CHANNEL_CONFIG)
                            .build())
                    .setBufferSizeInBytes(BUFFER_SIZE)
                    .setTransferMode(AudioTrack.MODE_STREAM)
                    .build();
            if (track.getState() != AudioTrack.STATE_INITIALIZED) {
                try { track.release(); } catch (Throwable ignore) {}
                Log.w(TAG, "AudioTrack not initialized");
                return false;
            }
            track.play();
            audioTrack = track;
            started = true;
            Log.i(TAG, "Audio player started, buffer=" + BUFFER_SIZE);
            return true;
        } catch (Throwable t) {
            Log.e(TAG, "Audio player start failed", t);
            releaseQuietly();
            return false;
        }
    }

    public synchronized void play(byte[] data, int length) {
        AudioTrack track = audioTrack;
        if (!started || track == null || data == null || length <= 0) return;
        try {
            track.write(data, 0, Math.min(length, data.length));
        } catch (Throwable t) {
            Log.w(TAG, "Audio write failed", t);
        }
    }

    public synchronized void stop() {
        started = false;
        releaseQuietly();
    }

    private void releaseQuietly() {
        AudioTrack track = audioTrack;
        audioTrack = null;
        if (track != null) {
            try { track.stop(); } catch (Throwable ignore) {}
            try { track.release(); } catch (Throwable ignore) {}
        }
    }
}
