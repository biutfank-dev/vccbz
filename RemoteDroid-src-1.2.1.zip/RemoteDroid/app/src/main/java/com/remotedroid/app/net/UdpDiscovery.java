package com.remotedroid.app.net;

import android.content.Context;
import android.util.Log;

import com.remotedroid.app.util.NetUtil;

import java.io.IOException;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;
import java.net.InetSocketAddress;
import java.net.Socket;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.atomic.AtomicBoolean;

public class UdpDiscovery {

    private static final String TAG = "UdpDiscovery";
    public static final int DISCOVERY_PORT = 8889;
    public static final String DISCOVERY_MSG = "REMOTEDROID_DISCOVER";
    public static final String RESPONSE_PREFIX = "REMOTEDROID_DEVICE:";

    private DatagramSocket socket;
    private AtomicBoolean running = new AtomicBoolean(false);
    private Thread receiveThread;
    private Thread broadcastThread;
    private Context context;
    private int tcpPort = 8888;
    private boolean isHost = false;
    private ConcurrentHashMap<String, DeviceInfo> foundDevices = new ConcurrentHashMap<>();
    private OnDeviceFoundListener listener;
    private ExecutorService scanExecutor;

    public interface OnDeviceFoundListener {
        void onDeviceFound(DeviceInfo device);
        void onDeviceListChanged(List<DeviceInfo> devices);
    }

    public static class DeviceInfo {
        public String name;
        public String ip;
        public int port;
        public long lastSeen;

        public DeviceInfo(String name, String ip, int port) {
            this.name = name;
            this.ip = ip;
            this.port = port;
            this.lastSeen = System.currentTimeMillis();
        }
    }

    public UdpDiscovery(Context context) {
        this.context = context.getApplicationContext();
        this.isHost = false;
    }

    public UdpDiscovery(Context context, int tcpPort) {
        this.context = context.getApplicationContext();
        this.tcpPort = tcpPort > 0 ? tcpPort : 8888;
        this.isHost = true;
    }

    public void setTcpPort(int tcpPort) {
        if (tcpPort > 0) this.tcpPort = tcpPort;
    }

    public void setOnDeviceFoundListener(OnDeviceFoundListener listener) {
        this.listener = listener;
    }

    public void start() {
        if (running.get()) return;
        running.set(true);
        foundDevices.clear();
        scanExecutor = Executors.newFixedThreadPool(20);
        try {
            try {
                socket = new DatagramSocket(null);
                socket.setReuseAddress(true);
                socket.bind(new InetSocketAddress(DISCOVERY_PORT));
            } catch (IOException bindErr) {
                Log.w(TAG, "Port busy, using ephemeral port", bindErr);
                socket = new DatagramSocket();
                socket.setReuseAddress(true);
            }
            socket.setBroadcast(true);
            socket.setSoTimeout(1000);
        } catch (IOException e) {
            Log.e(TAG, "Socket create failed", e);
            return;
        }
        receiveThread = new Thread(this::receiveLoop, "UDP-Receive");
        receiveThread.start();
        broadcastThread = new Thread(this::broadcastLoop, "UDP-Broadcast");
        broadcastThread.start();

        // 仅控制端启动TCP网段扫描，被控端不需要扫描
        if (!isHost) {
            try {
                startTcpScan();
            } catch (Throwable t) {
                Log.w(TAG, "tcp scan start failed", t);
            }
        }
    }

    /** 循环发送广播，3次，间隔1秒，提高接收成功率 */
    private void broadcastLoop() {
        for (int i = 0; i < 3 && running.get(); i++) {
            sendAllBroadcasts();
            try { Thread.sleep(1000); } catch (InterruptedException e) { return; }
        }
    }

    /** 发送到所有可能的广播地址，兼容不同路由器网段 */
    private void sendAllBroadcasts() {
        try {
            byte[] data = DISCOVERY_MSG.getBytes();
            List<String> broadcastAddresses = new ArrayList<>();
            broadcastAddresses.add("255.255.255.255");
            // 常见家用路由器网段广播
            broadcastAddresses.add("192.168.0.255");
            broadcastAddresses.add("192.168.1.255");
            broadcastAddresses.add("192.168.2.255");
            broadcastAddresses.add("192.168.31.255");
            broadcastAddresses.add("192.168.43.255"); // 手机热点
            broadcastAddresses.add("192.168.137.255"); // Windows热点
            // 自动计算当前网段广播地址
            String myIp = NetUtil.getWifiIpAddress(context);
            if (myIp != null && myIp.matches("\\d+\\.\\d+\\.\\d+\\.\\d+")) {
                String[] parts = myIp.split("\\.");
                broadcastAddresses.add(parts[0] + "." + parts[1] + "." + parts[2] + ".255");
            }
            for (String addr : broadcastAddresses) {
                try {
                    InetAddress bcast = InetAddress.getByName(addr);
                    DatagramPacket packet = new DatagramPacket(data, data.length, bcast, DISCOVERY_PORT);
                    socket.send(packet);
                } catch (Exception ignore) {}
            }
            Log.d(TAG, "Broadcast sent to all addresses");
        } catch (Exception e) {
            Log.e(TAG, "Broadcast failed", e);
        }
    }

    /** TCP扫描+握手校验：只有返回正确协议响应才加入列表，彻底过滤多余设备 */
    private void startTcpScan() {
        final ExecutorService executor = scanExecutor;
        if (executor == null) return;
        String myIp = NetUtil.getWifiIpAddress(context);
        if (myIp == null || !myIp.matches("\\d+\\.\\d+\\.\\d+\\.\\d+")) return;
        String[] parts = myIp.split("\\.");
        final String prefix = parts[0] + "." + parts[1] + "." + parts[2] + ".";
        for (int i = 1; i <= 254; i++) {
            final String ip = prefix + i;
            if (ip.equals(myIp)) continue;
            try {
                executor.execute(() -> {
                try (Socket probe = new Socket()) {
                    probe.connect(new InetSocketAddress(ip, tcpPort), 300);
                    probe.setSoTimeout(800);
                    java.io.DataOutputStream out = new java.io.DataOutputStream(probe.getOutputStream());
                    java.io.DataInputStream in = new java.io.DataInputStream(probe.getInputStream());
                    // 发送握手ping
                    byte[] pingData = VideoStreamServer.HANDSHAKE_PING.getBytes();
                    out.writeInt(VideoStreamServer.MSG_HANDSHAKE);
                    out.writeInt(pingData.length);
                    out.write(pingData);
                    out.flush();
                    // 读取响应
                    int msgType = in.readInt();
                    int len = in.readInt();
                    if (msgType != VideoStreamServer.MSG_HANDSHAKE || len <= 0) {
                        probe.close();
                        return;
                    }
                    byte[] resp = new byte[len];
                    in.readFully(resp);
                    String pong = new String(resp);
                    if (!pong.startsWith(VideoStreamServer.HANDSHAKE_PONG_PREFIX)) {
                        probe.close();
                        return;
                    }
                    // 握手通过，解析设备信息
                    String payload = pong.substring(VideoStreamServer.HANDSHAKE_PONG_PREFIX.length());
                    String[] devParts = payload.split("\\|");
                    String name = devParts.length >= 1 ? devParts[0] : "RemoteDroid设备";
                    int devPort = tcpPort;
                    if (devParts.length >= 2) {
                        try { devPort = Integer.parseInt(devParts[1]); } catch (Exception ignore) {}
                    }
                    String key = ip + ":" + devPort;
                    if (!foundDevices.containsKey(key)) {
                        DeviceInfo device = new DeviceInfo(name, ip, devPort);
                        foundDevices.put(key, device);
                        if (listener != null) {
                            listener.onDeviceFound(device);
                            listener.onDeviceListChanged(new ArrayList<>(foundDevices.values()));
                        }
                    }
                } catch (Exception ignore) {
                    // 连接失败/握手失败，不是本设备，直接忽略，不显示
                }
                });
            } catch (Throwable t) {
                // 线程池已关闭等情况，直接忽略
                Log.w(TAG, "tcp scan task rejected", t);
            }
        }
    }

    private void receiveLoop() {
        byte[] buffer = new byte[1024];
        while (running.get() && socket != null && !socket.isClosed()) {
            try {
                DatagramPacket packet = new DatagramPacket(buffer, buffer.length);
                socket.receive(packet);
                String msg = new String(packet.getData(), 0, packet.getLength());
                String senderIp = packet.getAddress().getHostAddress();
                String myIp = NetUtil.getWifiIpAddress(context);

                if (msg.equals(DISCOVERY_MSG)) {
                    if (!senderIp.equals(myIp)) {
                        String deviceName = NetUtil.getDeviceName();
                        String response = RESPONSE_PREFIX + deviceName + "|" + tcpPort;
                        byte[] respData = response.getBytes();
                        // 直接单播回复给发送方，不依赖广播
                        DatagramPacket resp = new DatagramPacket(respData, respData.length,
                                packet.getAddress(), packet.getPort());
                        socket.send(resp);
                    }
                } else if (msg.startsWith(RESPONSE_PREFIX)) {
                    String payload = msg.substring(RESPONSE_PREFIX.length());
                    String[] parts = payload.split("\\|");
                    if (parts.length >= 2) {
                        String name = parts[0];
                        int port = Integer.parseInt(parts[1]);
                        DeviceInfo device = new DeviceInfo(name, senderIp, port);
                        String key = senderIp + ":" + port;
                        foundDevices.put(key, device);
                        if (listener != null) {
                            listener.onDeviceFound(device);
                            listener.onDeviceListChanged(new ArrayList<>(foundDevices.values()));
                        }
                    }
                }
            } catch (IOException e) {
                // timeout是正常的，继续循环
            } catch (Exception e) {
                Log.w(TAG, "Receive loop error", e);
            }
        }
    }

    public void stop() {
        running.set(false);
        try {
            if (socket != null && !socket.isClosed()) socket.close();
        } catch (Throwable ignore) {}
        if (receiveThread != null) receiveThread.interrupt();
        if (broadcastThread != null) broadcastThread.interrupt();
        ExecutorService executor = scanExecutor;
        scanExecutor = null;
        if (executor != null) {
            try { executor.shutdownNow(); } catch (Throwable ignore) {}
        }
    }

    public List<DeviceInfo> getFoundDevices() {
        return new ArrayList<>(foundDevices.values());
    }

    public void clearDevices() {
        foundDevices.clear();
    }
}
