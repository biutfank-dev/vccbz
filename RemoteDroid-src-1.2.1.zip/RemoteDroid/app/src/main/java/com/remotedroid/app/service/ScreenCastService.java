package com.remotedroid.app.service;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.content.pm.ServiceInfo;
import android.hardware.display.DisplayManager;
import android.hardware.display.VirtualDisplay;
import android.media.MediaCodec;
import android.media.projection.MediaProjection;
import android.media.projection.MediaProjectionManager;
import android.os.Build;
import android.os.Handler;
import android.os.HandlerThread;
import android.os.IBinder;
import android.util.DisplayMetrics;
import android.util.Log;
import android.view.Surface;
import android.view.WindowManager;

import androidx.annotation.Nullable;
import androidx.core.app.NotificationCompat;

import com.remotedroid.app.R;
import com.remotedroid.app.net.UdpDiscovery;
import com.remotedroid.app.net.VideoStreamServer;
import com.remotedroid.app.util.TouchInjector;

import java.io.IOException;

/**
 * 屏幕采集前台服务（被控端）。
 *
 * 稳定性说明（v1.2.1）：
 * - 动态改分辨率/码率（reconfigure）做了幂等与重入保护：
 *   参数没变就不重建编码器；重建流程整体 try/catch，任何异常都不会闪退；
 * - 旧编码器先停线程再释放，避免“边解码边释放”导致的偶发原生崩溃；
 * - 新增编码分辨率下发（setEncodeInfo），控制端可准确初始化解码器。
 */
public class ScreenCastService extends Service {

    private static final String TAG = "ScreenCastService";
    private static final String CHANNEL_ID = "screen_cast_channel";
    private static final int NOTIFICATION_ID = 1001;

    public static final String EXTRA_RESULT_CODE = "result_code";
    public static final String EXTRA_RESULT_DATA = "result_data";
    public static final String EXTRA_USE_ROOT = "use_root";
    public static final String EXTRA_PORT = "port";

    private MediaProjection mediaProjection;
    private VirtualDisplay virtualDisplay;
    private H264Encoder encoder;
    private AudioCapture audioCapture;
    private VideoStreamServer server;
    private UdpDiscovery udpDiscovery;
    private boolean useRoot = false;
    private int port = 8888;
    private HandlerThread projectionThread;
    private Handler projectionHandler;
    private MediaProjection.Callback projectionCallback;

    // 当前生效的编码参数（用于幂等判断）
    private int encodeWidth = 0;
    private int encodeHeight = 0;
    private int currentResMode = 720;
    private int currentBrMode = 1;
    private boolean reconfiguring = false;

    @Override
    public void onCreate() {
        super.onCreate();
        createNotificationChannel();
        projectionThread = new HandlerThread("Projection-Thread");
        projectionThread.start();
        projectionHandler = new Handler(projectionThread.getLooper());
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        // 第一步：立即启动前台通知（必须在5秒内）
        startAsForeground();

        if (intent == null) {
            Log.e(TAG, "onStartCommand: intent is null");
            stopSelf();
            return START_NOT_STICKY;
        }

        // 注意：Activity.RESULT_OK 的值就是 -1，因此不能用 -1 作为“缺失”的哨兵值
        final int resultCode = intent.getIntExtra(EXTRA_RESULT_CODE, Integer.MIN_VALUE);
        final Intent resultData = intent.getParcelableExtra(EXTRA_RESULT_DATA);
        useRoot = intent.getBooleanExtra(EXTRA_USE_ROOT, false);
        port = intent.getIntExtra(EXTRA_PORT, 8888);

        Log.i(TAG, "onStartCommand resultCode=" + resultCode
                + " resultData=" + (resultData != null ? "present" : "NULL")
                + " useRoot=" + useRoot + " port=" + port);

        // 可靠的判据是投影结果 Intent 是否存在
        if (resultCode == Integer.MIN_VALUE || resultData == null) {
            Log.e(TAG, "No MediaProjection permission data");
            stopSelf();
            return START_NOT_STICKY;
        }

        // 在后台线程初始化，避免阻塞主线程
        projectionHandler.post(() -> initScreenCast(resultCode, resultData));

        return START_STICKY;
    }

    private void startAsForeground() {
        Notification notification = buildNotification();
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                // API 29+: 必须指定前台服务类型
                startForeground(NOTIFICATION_ID, notification,
                        ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION);
            } else {
                // API 24-28: 不需要类型
                startForeground(NOTIFICATION_ID, notification);
            }
        } catch (Throwable e) {
            Log.e(TAG, "startForeground failed, trying fallback", e);
            try {
                // 降级：不指定类型
                startForeground(NOTIFICATION_ID, notification);
            } catch (Throwable e2) {
                Log.e(TAG, "startForeground fallback also failed", e2);
            }
        }
    }

    private void initScreenCast(int resultCode, Intent resultData) {
        try {
            MediaProjectionManager mpm = (MediaProjectionManager)
                    getSystemService(Context.MEDIA_PROJECTION_SERVICE);
            if (mpm == null) {
                Log.e(TAG, "MediaProjectionManager is null");
                stopSelf();
                return;
            }

            // Android 14+ 要求在 getMediaProjection 前注册 Callback
            projectionCallback = new MediaProjection.Callback() {
                @Override
                public void onStop() {
                    Log.w(TAG, "MediaProjection stopped by system");
                    cleanup();
                    stopSelf();
                }
            };

            mediaProjection = mpm.getMediaProjection(resultCode, resultData);
            if (mediaProjection == null) {
                Log.e(TAG, "getMediaProjection returned null");
                stopSelf();
                return;
            }
            mediaProjection.registerCallback(projectionCallback, projectionHandler);

            // 获取屏幕尺寸
            WindowManager wm = (WindowManager) getSystemService(Context.WINDOW_SERVICE);
            DisplayMetrics metrics = new DisplayMetrics();
            wm.getDefaultDisplay().getRealMetrics(metrics);
            int screenWidth = metrics.widthPixels;
            int screenHeight = metrics.heightPixels;
            int density = metrics.densityDpi;

            // 初始编码分辨率：720p低延迟，减少数据量（控制端连接后可按需调整）
            int maxWidth = 720;
            encodeWidth = screenWidth;
            encodeHeight = screenHeight;
            if (encodeWidth > maxWidth) {
                float scale = (float) maxWidth / encodeWidth;
                encodeWidth = maxWidth;
                encodeHeight = Math.round(encodeHeight * scale);
            }
            encodeWidth = align16(encodeWidth);
            encodeHeight = align16(encodeHeight);

            // 初始码率：低码率，局域网流畅不卡顿
            int bitrate = Math.min(encodeWidth * encodeHeight * 2, 2_000_000);
            int frameRate = 20;

            currentResMode = 720;
            currentBrMode = 1;

            Log.i(TAG, "Screen: " + screenWidth + "x" + screenHeight
                    + " Encode: " + encodeWidth + "x" + encodeHeight
                    + " bitrate=" + bitrate + " fps=" + frameRate);

            // 启动TCP服务器
            server = new VideoStreamServer(port);
            server.setScreenInfo(screenWidth, screenHeight);
            server.setEncodeInfo(encodeWidth, encodeHeight);
            server.setOnTouchEventListener((action, x, y, meta) -> {
                TouchInjector.injectTouch(useRoot, action, x, y, meta);
            });
            server.setOnSwipeEventListener((x1, y1, x2, y2, duration) -> {
                TouchInjector.injectSwipe(useRoot, x1, y1, x2, y2, duration);
            });
            // 接收主控端的分辨率/码率配置
            server.setOnConfigListener((resMode, brMode) -> {
                projectionHandler.post(() -> reconfigureEncoder(resMode, brMode));
            });
            server.start();

            // 启动UDP设备发现
            try {
                udpDiscovery = new UdpDiscovery(this, port);
                udpDiscovery.start();
            } catch (Throwable udpErr) {
                Log.w(TAG, "UDP discovery failed, manual IP still works", udpErr);
            }

            // 先启动编码器，再获取输入Surface
            encoder = new H264Encoder(encodeWidth, encodeHeight, bitrate, frameRate);
            encoder.setOnEncodedFrameListener((data, pts, flags) -> {
                VideoStreamServer s = server;
                if (s == null) return;
                if ((flags & MediaCodec.BUFFER_FLAG_CODEC_CONFIG) != 0) {
                    s.setCodecConfig(data);
                } else {
                    s.sendVideoFrame(data, pts);
                }
            });
            encoder.start();
            // 编码器启动后同步已缓存的配置（如果有）
            byte[] config = encoder.getCodecConfigData();
            if (config != null && server != null) {
                server.setCodecConfig(config);
            }
            Surface encoderSurface = encoder.getInputSurface();

            // 拿到有效Surface后再创建VirtualDisplay
            virtualDisplay = mediaProjection.createVirtualDisplay(
                    "ScreenCast",
                    encodeWidth,
                    encodeHeight,
                    density,
                    DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR,
                    encoderSurface,
                    null,
                    projectionHandler
            );

            // 启动系统音频采集（内放/耳机声音）
            audioCapture = new AudioCapture(mediaProjection);
            audioCapture.setOnAudioDataListener((data, len) -> {
                VideoStreamServer s = server;
                if (s != null) s.sendAudioFrame(data, len);
            });
            audioCapture.start();

            Log.i(TAG, "Screen cast + audio started successfully");
        } catch (IOException e) {
            Log.e(TAG, "Failed to start encoder", e);
            stopSelf();
        } catch (SecurityException e) {
            Log.e(TAG, "SecurityException - permission issue", e);
            stopSelf();
        } catch (Throwable e) {
            Log.e(TAG, "Unexpected error in initScreenCast", e);
            stopSelf();
        }
    }

    private static int align16(int v) {
        return Math.max(16, (v + 15) / 16 * 16);
    }

    private Notification buildNotification() {
        return new NotificationCompat.Builder(this, CHANNEL_ID)
                .setContentTitle("RemoteDroid")
                .setContentText("屏幕共享中…")
                .setSmallIcon(R.drawable.ic_launcher)
                .setOngoing(true)
                .setPriority(NotificationCompat.PRIORITY_LOW)
                .build();
    }

    private void createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            NotificationChannel channel = new NotificationChannel(
                    CHANNEL_ID, "屏幕共享", NotificationManager.IMPORTANCE_LOW);
            channel.setShowBadge(false);
            NotificationManager nm = getSystemService(NotificationManager.class);
            if (nm != null) nm.createNotificationChannel(channel);
        }
    }

    /**
     * 根据主控端配置动态调整分辨率和码率。
     * 幂等：参数没变直接跳过；重建过程整体加锁+异常兜底。
     */
    private void reconfigureEncoder(int resMode, int brMode) {
        if (reconfiguring) {
            Log.w(TAG, "Reconfigure already in progress, skip");
            return;
        }
        if (mediaProjection == null || server == null) {
            Log.w(TAG, "Reconfigure skipped: service not ready");
            return;
        }
        // 参数没变且编码器健康时无需重建
        if (encoder != null && resMode == currentResMode && brMode == currentBrMode) {
            Log.i(TAG, "Reconfigure skipped: params unchanged (" + resMode + "/" + brMode + ")");
            return;
        }
        reconfiguring = true;
        try {
            // 停止旧编码器和虚拟屏（先释放虚拟屏，再停编码器线程，最后释放编码器）
            if (virtualDisplay != null) {
                try { virtualDisplay.release(); } catch (Throwable ignore) {}
                virtualDisplay = null;
            }
            H264Encoder oldEncoder = encoder;
            encoder = null;
            if (oldEncoder != null) {
                try { oldEncoder.stop(); } catch (Throwable ignore) {}
            }

            WindowManager wm = (WindowManager) getSystemService(Context.WINDOW_SERVICE);
            DisplayMetrics metrics = new DisplayMetrics();
            wm.getDefaultDisplay().getRealMetrics(metrics);
            int screenWidth = metrics.widthPixels;
            int screenHeight = metrics.heightPixels;
            int density = metrics.densityDpi;

            // 计算目标宽度
            int maxWidth;
            if (resMode == 720) maxWidth = 720;
            else if (resMode == 1440) maxWidth = 1440;
            else maxWidth = 1080;

            int newWidth = screenWidth;
            int newHeight = screenHeight;
            if (newWidth > maxWidth) {
                float scale = (float) maxWidth / newWidth;
                newWidth = maxWidth;
                newHeight = Math.round(newHeight * scale);
            }
            newWidth = align16(newWidth);
            newHeight = align16(newHeight);

            // 独立码率：低=2M，中=4M，高=8M，与分辨率无关
            int bitrate;
            if (brMode == 2) bitrate = 4_000_000;
            else if (brMode == 3) bitrate = 8_000_000;
            else bitrate = 2_000_000;
            int frameRate = 20;

            Log.i(TAG, "Reconfiguring to: " + newWidth + "x" + newHeight
                    + " bitrate=" + bitrate);

            H264Encoder newEncoder = new H264Encoder(newWidth, newHeight, bitrate, frameRate);
            newEncoder.setOnEncodedFrameListener((data, pts, flags) -> {
                VideoStreamServer s = server;
                if (s == null) return;
                if ((flags & MediaCodec.BUFFER_FLAG_CODEC_CONFIG) != 0) {
                    s.setCodecConfig(data);
                } else {
                    s.sendVideoFrame(data, pts);
                }
            });
            newEncoder.start();

            encodeWidth = newWidth;
            encodeHeight = newHeight;
            encoder = newEncoder;

            byte[] config = newEncoder.getCodecConfigData();
            if (config != null && server != null) {
                server.setCodecConfig(config);
            }
            server.setEncodeInfo(encodeWidth, encodeHeight);

            virtualDisplay = mediaProjection.createVirtualDisplay(
                    "ScreenCast",
                    encodeWidth, encodeHeight, density,
                    DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR,
                    newEncoder.getInputSurface(), null, projectionHandler);

            currentResMode = resMode;
            currentBrMode = brMode;
            Log.i(TAG, "Reconfigure done: " + encodeWidth + "x" + encodeHeight);
        } catch (Throwable e) {
            Log.e(TAG, "Reconfigure failed", e);
        } finally {
            reconfiguring = false;
        }
    }

    private void cleanup() {
        try {
            if (udpDiscovery != null) {
                try { udpDiscovery.stop(); } catch (Throwable e) { e.printStackTrace(); }
                udpDiscovery = null;
            }
        } catch (Throwable ignore) {}
        try {
            if (virtualDisplay != null) {
                virtualDisplay.release();
                virtualDisplay = null;
            }
        } catch (Throwable ignore) {}
        try {
            if (encoder != null) {
                encoder.stop();
                encoder = null;
            }
        } catch (Throwable ignore) {}
        try {
            if (audioCapture != null) {
                audioCapture.stop();
                audioCapture = null;
            }
        } catch (Throwable ignore) {}
        try {
            if (server != null) {
                server.stop();
                server = null;
            }
        } catch (Throwable ignore) {}
        try {
            if (mediaProjection != null) {
                try {
                    if (projectionCallback != null) {
                        mediaProjection.unregisterCallback(projectionCallback);
                    }
                } catch (Throwable e) { e.printStackTrace(); }
                try { mediaProjection.stop(); } catch (Throwable e) { e.printStackTrace(); }
                mediaProjection = null;
            }
        } catch (Throwable ignore) {}
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        cleanup();
        if (projectionThread != null) {
            projectionThread.quitSafely();
            projectionThread = null;
        }
        Log.i(TAG, "Screen cast service destroyed");
    }

    @Nullable
    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }
}
