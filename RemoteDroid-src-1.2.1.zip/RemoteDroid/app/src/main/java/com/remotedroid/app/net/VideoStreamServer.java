package com.remotedroid.app.net;

import android.util.Log;

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.concurrent.CopyOnWriteArrayList;
import java.util.concurrent.atomic.AtomicBoolean;

/**
 * 被控端TCP服务器：接受控制端连接，发送H264视频流，接收触摸事件。
 *
 * 稳定性说明（v1.2.1）：
 * - 每个客户端连接独立线程，单条消息解析失败不会断开连接、更不会崩溃；
 * - 所有监听器回调都有异常兜底；
 * - 新增编码分辨率下发（MSG_ENCODE_INFO），控制端可据此精确初始化解码器。
 */
public class VideoStreamServer {

    private static final String TAG = "VideoStreamServer";
    public static final int DEFAULT_PORT = 8888;

    public static final int MSG_VIDEO_FRAME = 1;
    public static final int MSG_TOUCH_EVENT = 2;
    public static final int MSG_SCREEN_INFO = 3;
    public static final int MSG_HEARTBEAT = 4;
    public static final int MSG_SWIPE_EVENT = 5;
    public static final int MSG_CODEC_CONFIG = 6;
    public static final int MSG_AUDIO_FRAME = 7;
    public static final int MSG_HANDSHAKE = 8;
    public static final int MSG_CONFIG = 9;
    public static final int MSG_ENCODE_INFO = 10;
    public static final String HANDSHAKE_PING = "REMOTEDROID_PING";
    public static final String HANDSHAKE_PONG_PREFIX = "REMOTEDROID_PONG:";

    private ServerSocket serverSocket;
    private AtomicBoolean running = new AtomicBoolean(false);
    private CopyOnWriteArrayList<ClientHandler> clients = new CopyOnWriteArrayList<>();
    private OnTouchEventListener touchListener;
    private OnSwipeEventListener swipeListener;
    private OnConfigListener configListener;
    private OnConnectionListener connectionListener;
    private int port;
    private int screenWidth;
    private int screenHeight;
    private int encodeWidth = 0;
    private int encodeHeight = 0;
    private byte[] codecConfig = null;

    public interface OnTouchEventListener {
        void onTouchEvent(int action, float x, float y, int meta);
    }

    public interface OnSwipeEventListener {
        void onSwipeEvent(float x1, float y1, float x2, float y2, int duration);
    }

    public interface OnConfigListener {
        void onConfig(int resolutionMode, int bitrateMode);
    }

    public interface OnConnectionListener {
        void onClientConnected();
        void onClientDisconnected();
    }

    public VideoStreamServer(int port) {
        this.port = port;
    }

    public void setOnTouchEventListener(OnTouchEventListener listener) {
        this.touchListener = listener;
    }

    public void setOnSwipeEventListener(OnSwipeEventListener listener) {
        this.swipeListener = listener;
    }

    public void setOnConfigListener(OnConfigListener listener) {
        this.configListener = listener;
    }

    public void setOnConnectionListener(OnConnectionListener listener) {
        this.connectionListener = listener;
    }

    /** 物理屏幕分辨率（用于控制端触摸映射） */
    public void setScreenInfo(int width, int height) {
        this.screenWidth = width;
        this.screenHeight = height;
        Log.i(TAG, "setScreenInfo " + width + "x" + height + " clients=" + clients.size());
        broadcast(MSG_SCREEN_INFO, (width + "x" + height).getBytes());
    }

    /** 实际编码分辨率（用于控制端解码器初始化） */
    public void setEncodeInfo(int width, int height) {
        this.encodeWidth = width;
        this.encodeHeight = height;
        Log.i(TAG, "setEncodeInfo " + width + "x" + height + " clients=" + clients.size());
        broadcast(MSG_ENCODE_INFO, (width + "x" + height).getBytes());
    }

    public void setCodecConfig(byte[] config) {
        this.codecConfig = config;
        broadcast(MSG_CODEC_CONFIG, config);
    }

    private void broadcast(int type, byte[] data) {
        for (ClientHandler c : clients) {
            c.sendMessage(type, data);
        }
    }

    public void start() {
        if (running.getAndSet(true)) return;
        new Thread(() -> {
            try {
                serverSocket = new ServerSocket(port);
                Log.i(TAG, "Server started on port " + port);
                while (running.get() && serverSocket != null && !serverSocket.isClosed()) {
                    try {
                        Socket socket = serverSocket.accept();
                        socket.setTcpNoDelay(true); // 禁用Nagle，降低延迟
                        socket.setSendBufferSize(512 * 1024);
                        socket.setReceiveBufferSize(128 * 1024);
                        Log.i(TAG, "Client connected: " + socket.getInetAddress());
                        ClientHandler handler = new ClientHandler(socket);
                        clients.add(handler);
                        handler.start();
                        try {
                            if (connectionListener != null) {
                                connectionListener.onClientConnected();
                            }
                        } catch (Throwable t) {
                            Log.w(TAG, "connect listener error", t);
                        }
                    } catch (IOException e) {
                        if (running.get()) Log.e(TAG, "Accept error", e);
                    } catch (Throwable t) {
                        if (running.get()) Log.e(TAG, "Accept loop error", t);
                    }
                }
            } catch (Throwable t) {
                Log.e(TAG, "Server socket error", t);
            }
        }, "TCP-Server").start();
    }

    public void stop() {
        running.set(false);
        for (ClientHandler c : clients) c.close();
        clients.clear();
        ServerSocket ss = serverSocket;
        serverSocket = null;
        if (ss != null && !ss.isClosed()) {
            try { ss.close(); } catch (IOException e) { e.printStackTrace(); }
        }
    }

    public void sendVideoFrame(byte[] data, long presentationTimeUs) {
        for (ClientHandler c : clients) {
            c.sendVideoFrame(data, presentationTimeUs);
        }
    }

    public void sendAudioFrame(byte[] data, int length) {
        for (ClientHandler c : clients) {
            c.sendAudioFrame(data, length);
        }
    }

    public int getClientCount() {
        return clients.size();
    }

    private class ClientHandler {
        private Socket socket;
        private DataOutputStream out;
        private DataInputStream in;
        private AtomicBoolean alive = new AtomicBoolean(true);

        ClientHandler(Socket socket) {
            this.socket = socket;
            try {
                this.out = new DataOutputStream(socket.getOutputStream());
                this.in = new DataInputStream(socket.getInputStream());
            } catch (IOException e) {
                Log.e(TAG, "Client handler init failed", e);
            }
        }

        void start() {
            new Thread(() -> {
                Log.i(TAG, "ClientHandler started, server screen="
                        + screenWidth + "x" + screenHeight + " out=" + (out != null));
                try {
                    // 先发送SPS/PPS配置
                    if (codecConfig != null) {
                        sendMessage(MSG_CODEC_CONFIG, codecConfig);
                        Log.i(TAG, "Codec config sent to new client, size=" + codecConfig.length);
                    }
                    if (screenWidth > 0 && screenHeight > 0) {
                        sendMessage(MSG_SCREEN_INFO,
                                (screenWidth + "x" + screenHeight).getBytes());
                        Log.i(TAG, "SCREEN_INFO sent to new client");
                    }
                    if (encodeWidth > 0 && encodeHeight > 0) {
                        sendMessage(MSG_ENCODE_INFO,
                                (encodeWidth + "x" + encodeHeight).getBytes());
                        Log.i(TAG, "ENCODE_INFO sent to new client");
                    }
                    while (alive.get() && !socket.isClosed() && in != null) {
                        int msgType;
                        int length;
                        byte[] data;
                        try {
                            msgType = in.readInt();
                            length = in.readInt();
                            if (length < 0 || length > 1024 * 1024) {
                                break;
                            }
                            data = new byte[length];
                            in.readFully(data);
                        } catch (IOException e) {
                            break;
                        } catch (Throwable t) {
                            Log.w(TAG, "client read error", t);
                            break;
                        }
                        try {
                            handleClientMessage(msgType, data);
                        } catch (Throwable t) {
                            // 单条消息处理失败不影响连接，更不会让进程崩溃
                            Log.w(TAG, "handle message failed, type=" + msgType, t);
                        }
                    }
                } catch (Throwable t) {
                    Log.w(TAG, "client handler error", t);
                } finally {
                    close();
                    clients.remove(ClientHandler.this);
                    try {
                        if (connectionListener != null) {
                            connectionListener.onClientDisconnected();
                        }
                    } catch (Throwable t) {
                        Log.w(TAG, "disconnect listener error", t);
                    }
                }
            }, "TCP-Client-Recv").start();
        }

        private void handleClientMessage(int msgType, byte[] data) {
            // 握手探测：回复设备信息，用于扫描校验，过滤非本协议设备
            if (msgType == MSG_HANDSHAKE) {
                String ping = new String(data);
                if (HANDSHAKE_PING.equals(ping)) {
                    String deviceName = com.remotedroid.app.util.NetUtil.getDeviceName();
                    String pong = HANDSHAKE_PONG_PREFIX + deviceName + "|" + port;
                    sendMessage(MSG_HANDSHAKE, pong.getBytes());
                }
                return;
            }

            if (msgType == MSG_TOUCH_EVENT && data.length >= 16) {
                int action = bytesToInt(data, 0);
                float x = Float.intBitsToFloat(bytesToInt(data, 4));
                float y = Float.intBitsToFloat(bytesToInt(data, 8));
                int meta = bytesToInt(data, 12);
                try {
                    if (touchListener != null) {
                        touchListener.onTouchEvent(action, x, y, meta);
                    }
                } catch (Throwable t) {
                    Log.w(TAG, "touch listener error", t);
                }
            } else if (msgType == MSG_SWIPE_EVENT && data.length >= 20) {
                float x1 = Float.intBitsToFloat(bytesToInt(data, 0));
                float y1 = Float.intBitsToFloat(bytesToInt(data, 4));
                float x2 = Float.intBitsToFloat(bytesToInt(data, 8));
                float y2 = Float.intBitsToFloat(bytesToInt(data, 12));
                int duration = bytesToInt(data, 16);
                try {
                    if (swipeListener != null) {
                        swipeListener.onSwipeEvent(x1, y1, x2, y2, duration);
                    }
                } catch (Throwable t) {
                    Log.w(TAG, "swipe listener error", t);
                }
            } else if (msgType == MSG_CONFIG && data.length >= 8) {
                int resMode = bytesToInt(data, 0);
                int brMode = bytesToInt(data, 4);
                try {
                    if (configListener != null) {
                        configListener.onConfig(resMode, brMode);
                    }
                } catch (Throwable t) {
                    Log.w(TAG, "config listener error", t);
                }
            }
        }

        void sendVideoFrame(byte[] data, long presentationTimeUs) {
            if (!alive.get() || out == null) return;
            try {
                synchronized (out) {
                    out.writeInt(MSG_VIDEO_FRAME);
                    out.writeInt(data.length + 8);
                    out.writeLong(presentationTimeUs);
                    out.write(data);
                    out.flush();
                }
            } catch (IOException e) {
                close();
            }
        }

        void sendAudioFrame(byte[] data, int length) {
            if (!alive.get() || out == null) return;
            try {
                synchronized (out) {
                    out.writeInt(MSG_AUDIO_FRAME);
                    out.writeInt(length);
                    out.write(data, 0, length);
                    out.flush();
                }
            } catch (IOException e) {
                close();
            }
        }

        void sendMessage(int type, byte[] data) {
            if (!alive.get() || out == null) return;
            try {
                synchronized (out) {
                    out.writeInt(type);
                    out.writeInt(data.length);
                    out.write(data);
                    out.flush();
                }
            } catch (IOException e) {
                close();
            }
        }

        void close() {
            alive.set(false);
            try { if (out != null) out.close(); } catch (IOException e) {}
            try { if (in != null) in.close(); } catch (IOException e) {}
            try { if (socket != null && !socket.isClosed()) socket.close(); } catch (IOException e) {}
        }
    }

    private static int bytesToInt(byte[] b, int offset) {
        return ((b[offset] & 0xFF) << 24) | ((b[offset+1] & 0xFF) << 16)
                | ((b[offset+2] & 0xFF) << 8) | (b[offset+3] & 0xFF);
    }
}
