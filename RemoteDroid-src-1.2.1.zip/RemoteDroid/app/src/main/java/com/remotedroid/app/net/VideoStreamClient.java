package com.remotedroid.app.net;

import android.util.Log;

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.net.InetSocketAddress;
import java.net.Socket;
import java.nio.ByteBuffer;
import java.util.concurrent.atomic.AtomicBoolean;

/**
 * 控制端TCP客户端：连接被控端，接收H264视频流，发送触摸事件。
 *
 * 稳定性说明（v1.2.1）：
 * - 连接带超时，失败时只回调 onError，不会卡死；
 * - 接收线程内所有消息的单条解析异常均被捕获，绝不因坏数据导致崩溃；
 * - 断线/手动断开只通知一次，避免重复回调；
 * - 任意线程调用 disconnect() 都是安全的。
 */
public class VideoStreamClient {

    private static final String TAG = "VideoStreamClient";
    private static final int CONNECT_TIMEOUT_MS = 8000;
    private static final int MAX_PAYLOAD = 8 * 1024 * 1024;

    private final Object socketLock = new Object();
    private Socket socket;
    private DataInputStream in;
    private DataOutputStream out;
    private final AtomicBoolean connected = new AtomicBoolean(false);
    private final AtomicBoolean finishedNotified = new AtomicBoolean(true);
    private Thread connectThread;
    private Thread receiveThread;
    private OnFrameListener frameListener;
    private OnConnectionListener connectionListener;
    private final String host;
    private final int port;
    private int remoteWidth = 1080;
    private int remoteHeight = 1920;
    private int encodeWidth = 0;
    private int encodeHeight = 0;

    public interface OnFrameListener {
        void onVideoFrame(byte[] data, long presentationTimeUs);
        void onScreenInfo(int width, int height);
        void onCodecConfig(byte[] config);
        void onAudioFrame(byte[] data, int length);
        void onEncodeInfo(int width, int height);
    }

    public interface OnConnectionListener {
        void onConnected();
        void onDisconnected(String reason);
        void onError(String error);
    }

    public VideoStreamClient(String host, int port) {
        this.host = host;
        this.port = port;
    }

    public void setOnFrameListener(OnFrameListener listener) {
        this.frameListener = listener;
    }

    public void setOnConnectionListener(OnConnectionListener listener) {
        this.connectionListener = listener;
    }

    public int getRemoteWidth() { return remoteWidth; }
    public int getRemoteHeight() { return remoteHeight; }
    public int getEncodeWidth() { return encodeWidth; }
    public int getEncodeHeight() { return encodeHeight; }

    /** 发起连接（异步）。重复调用安全。 */
    public void connect() {
        synchronized (socketLock) {
            if (connectThread != null) return;
        }
        connectThread = new Thread(this::connectInternal, "TCP-Client");
        connectThread.start();
    }

    private void connectInternal() {
        try {
            Socket s = new Socket();
            s.connect(new InetSocketAddress(host, port), CONNECT_TIMEOUT_MS);
            s.setTcpNoDelay(true);
            try { s.setReceiveBufferSize(1024 * 1024); } catch (Exception ignore) {}
            synchronized (socketLock) {
                socket = s;
                in = new DataInputStream(s.getInputStream());
                out = new DataOutputStream(s.getOutputStream());
            }
            connected.set(true);
            finishedNotified.set(false);
            Log.i(TAG, "Connected to " + host + ":" + port);
            notifyConnected();
            startReceiveLoop();
        } catch (Throwable t) {
            Log.e(TAG, "Connection failed", t);
            notifyError(describe(t));
            closeQuietly();
        }
    }

    private void startReceiveLoop() {
        receiveThread = new Thread(() -> {
            try {
                receiveLoop();
            } catch (Throwable t) {
                Log.e(TAG, "Receive loop terminated", t);
            } finally {
                closeQuietly();
                notifyDisconnectedIfNeeded("connection closed");
            }
        }, "TCP-Receive");
        receiveThread.start();
    }

    private void receiveLoop() throws IOException {
        DataInputStream stream;
        synchronized (socketLock) { stream = in; }
        if (stream == null) return;
        while (connected.get() && !Thread.currentThread().isInterrupted()) {
            int msgType = stream.readInt();
            int length = stream.readInt();
            if (length < 0 || length > MAX_PAYLOAD) {
                Log.e(TAG, "Invalid frame length " + length + ", dropping connection");
                break;
            }
            byte[] data = new byte[length];
            stream.readFully(data);
            try {
                dispatch(msgType, data);
            } catch (Throwable t) {
                // 单条消息解析失败不影响后续消息，绝不向上抛出
                Log.w(TAG, "Failed to handle message type=" + msgType, t);
            }
        }
    }

    private void dispatch(int msgType, byte[] data) {
        switch (msgType) {
            case VideoStreamServer.MSG_VIDEO_FRAME:
                if (data.length >= 8) {
                    long pts = bytesToLong(data, 0);
                    byte[] frameData = new byte[data.length - 8];
                    System.arraycopy(data, 8, frameData, 0, frameData.length);
                    OnFrameListener l = frameListener;
                    if (l != null) l.onVideoFrame(frameData, pts);
                }
                break;
            case VideoStreamServer.MSG_SCREEN_INFO: {
                int[] wh = parseSize(data);
                if (wh != null) {
                    remoteWidth = wh[0];
                    remoteHeight = wh[1];
                    OnFrameListener l = frameListener;
                    if (l != null) l.onScreenInfo(remoteWidth, remoteHeight);
                }
                break;
            }
            case VideoStreamServer.MSG_ENCODE_INFO: {
                int[] wh = parseSize(data);
                if (wh != null) {
                    encodeWidth = wh[0];
                    encodeHeight = wh[1];
                    OnFrameListener l = frameListener;
                    if (l != null) l.onEncodeInfo(encodeWidth, encodeHeight);
                }
                break;
            }
            case VideoStreamServer.MSG_CODEC_CONFIG: {
                OnFrameListener l = frameListener;
                if (l != null) l.onCodecConfig(data);
                break;
            }
            case VideoStreamServer.MSG_AUDIO_FRAME: {
                OnFrameListener l = frameListener;
                if (l != null) l.onAudioFrame(data, data.length);
                break;
            }
            default:
                break;
        }
    }

    private static int[] parseSize(byte[] data) {
        try {
            String info = new String(data, "UTF-8").trim();
            String[] parts = info.contains("x") || info.contains("X")
                    ? info.split("[xX]") : info.split(":");
            if (parts.length >= 2) {
                int w = Integer.parseInt(parts[0].trim());
                int h = Integer.parseInt(parts[1].trim());
                if (w > 0 && h > 0) return new int[]{w, h};
            }
        } catch (Throwable t) {
            Log.w(TAG, "Bad size info message", t);
        }
        return null;
    }

    /** 发送触摸事件 */
    public void sendTouchEvent(int action, float x, float y, int meta) {
        try {
            DataOutputStream o = out();
            if (!connected.get() || o == null) return;
            ByteBuffer buf = ByteBuffer.allocate(16);
            buf.putInt(action);
            buf.putFloat(x);
            buf.putFloat(y);
            buf.putInt(meta);
            synchronized (o) {
                o.writeInt(VideoStreamServer.MSG_TOUCH_EVENT);
                o.writeInt(16);
                o.write(buf.array());
                o.flush();
            }
        } catch (Throwable t) {
            Log.w(TAG, "Send touch failed", t);
        }
    }

    /** 发送滑动手势 */
    public void sendSwipeEvent(float x1, float y1, float x2, float y2, int duration) {
        try {
            DataOutputStream o = out();
            if (!connected.get() || o == null) return;
            ByteBuffer buf = ByteBuffer.allocate(20);
            buf.putFloat(x1);
            buf.putFloat(y1);
            buf.putFloat(x2);
            buf.putFloat(y2);
            buf.putInt(duration);
            synchronized (o) {
                o.writeInt(VideoStreamServer.MSG_SWIPE_EVENT);
                o.writeInt(20);
                o.write(buf.array());
                o.flush();
            }
        } catch (Throwable t) {
            Log.w(TAG, "Send swipe failed", t);
        }
    }

    /** 发送分辨率和码率配置给被控端 */
    public void sendConfig(int resolutionMode, int bitrateMode) {
        try {
            DataOutputStream o = out();
            if (!connected.get() || o == null) return;
            ByteBuffer buf = ByteBuffer.allocate(8);
            buf.putInt(resolutionMode);
            buf.putInt(bitrateMode);
            synchronized (o) {
                o.writeInt(VideoStreamServer.MSG_CONFIG);
                o.writeInt(8);
                o.write(buf.array());
                o.flush();
            }
        } catch (Throwable t) {
            Log.w(TAG, "Send config failed", t);
        }
    }

    public boolean isConnected() {
        return connected.get() && socket != null && !socket.isClosed();
    }

    /** 主动断开（幂等，可在任意线程调用） */
    public void disconnect() {
        connected.set(false);
        closeQuietly();
        Thread t = receiveThread;
        if (t != null && t != Thread.currentThread()) {
            t.interrupt();
        }
        notifyDisconnectedIfNeeded("disconnected");
    }

    private DataOutputStream out() {
        synchronized (socketLock) { return out; }
    }

    private void closeQuietly() {
        synchronized (socketLock) {
            try { if (out != null) out.close(); } catch (Throwable ignore) {}
            try { if (in != null) in.close(); } catch (Throwable ignore) {}
            try { if (socket != null && !socket.isClosed()) socket.close(); } catch (Throwable ignore) {}
        }
    }

    private void notifyConnected() {
        try {
            if (connectionListener != null) connectionListener.onConnected();
        } catch (Throwable t) {
            Log.w(TAG, "onConnected listener error", t);
        }
    }

    private void notifyError(String error) {
        try {
            if (connectionListener != null) connectionListener.onError(error);
        } catch (Throwable t) {
            Log.w(TAG, "onError listener error", t);
        }
    }

    private void notifyDisconnectedIfNeeded(String reason) {
        if (!finishedNotified.compareAndSet(false, true)) return;
        try {
            if (connectionListener != null) connectionListener.onDisconnected(reason);
        } catch (Throwable t) {
            Log.w(TAG, "onDisconnected listener error", t);
        }
    }

    private static String describe(Throwable t) {
        String m = t.getMessage();
        return m != null ? m : t.toString();
    }

    private static long bytesToLong(byte[] b, int offset) {
        return ((long)(b[offset] & 0xFF) << 56) | ((long)(b[offset+1] & 0xFF) << 48)
                | ((long)(b[offset+2] & 0xFF) << 40) | ((long)(b[offset+3] & 0xFF) << 32)
                | ((long)(b[offset+4] & 0xFF) << 24) | ((long)(b[offset+5] & 0xFF) << 16)
                | ((long)(b[offset+6] & 0xFF) << 8) | (b[offset+7] & 0xFF);
    }
}
