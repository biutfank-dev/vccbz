package com.remotedroid.app.util;

import android.util.Log;

import java.io.File;
import java.io.FileWriter;
import java.io.PrintWriter;
import java.io.StringWriter;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

/**
 * 全局崩溃捕获：记录崩溃日志，避免无信息闪退
 */
public class CrashHandler implements Thread.UncaughtExceptionHandler {

    private static final String TAG = "CrashHandler";
    private static CrashHandler instance;
    private Thread.UncaughtExceptionHandler defaultHandler;
    private String logDir;

    private CrashHandler() {}

    public static synchronized void init(String logDir) {
        if (instance == null) {
            instance = new CrashHandler();
            instance.logDir = logDir;
            instance.defaultHandler = Thread.getDefaultUncaughtExceptionHandler();
            Thread.setDefaultUncaughtExceptionHandler(instance);
        }
    }

    @Override
    public void uncaughtException(Thread t, Throwable e) {
        Log.e(TAG, "Uncaught exception on thread " + t.getName(), e);
        try {
            writeCrashLog(t, e);
        } catch (Exception ignored) {}
        // 交给系统默认处理（退出应用）
        if (defaultHandler != null) {
            defaultHandler.uncaughtException(t, e);
        }
    }

    private void writeCrashLog(Thread t, Throwable e) throws Exception {
        File dir = new File(logDir);
        if (!dir.exists()) dir.mkdirs();
        String ts = new SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(new Date());
        File file = new File(dir, "crash_" + ts + ".log");
        StringWriter sw = new StringWriter();
        PrintWriter pw = new PrintWriter(sw);
        pw.println("Time: " + new Date());
        pw.println("Thread: " + t.getName());
        pw.println("Android: " + android.os.Build.VERSION.RELEASE
                + " SDK=" + android.os.Build.VERSION.SDK_INT);
        pw.println("Device: " + android.os.Build.MANUFACTURER + " " + android.os.Build.MODEL);
        pw.println();
        e.printStackTrace(pw);
        FileWriter fw = new FileWriter(file);
        fw.write(sw.toString());
        fw.close();
        Log.i(TAG, "Crash log written: " + file.getAbsolutePath());
    }
}
