package com.remotedroid.app.service;

import android.media.AudioAttributes;
import android.media.AudioFormat;
import android.media.AudioPlaybackCaptureConfiguration;
import android.media.AudioRecord;
import android.media.projection.MediaProjection;
import android.os.Build;
import android.util.Log;

import java.util.concurrent.atomic.AtomicBoolean;

/**
 * 音频采集：捕获被控端系统声音（设备内放、插耳机时也可采集），PCM格式
 */
public class AudioCapture {
    private static final String TAG = "AudioCapture";
    public static final int SAMPLE_RATE = 44100;
    public static final int CHANNEL_CONFIG = AudioFormat.CHANNEL_IN_STEREO;
    public static final int AUDIO_FORMAT = AudioFormat.ENCODING_PCM_16BIT;
    private static final int BUFFER_SIZE = calcBufferSize();

    private static int calcBufferSize() {
        try {
            int min = AudioRecord.getMinBufferSize(SAMPLE_RATE, CHANNEL_CONFIG, AUDIO_FORMAT);
            if (min > 0) return min * 2;
        } catch (Throwable t) {
            Log.w(TAG, "getMinBufferSize failed", t);
        }
        return 16384; // 兜底
    }

    private AudioRecord audioRecord;
    private AtomicBoolean running = new AtomicBoolean(false);
    private Thread captureThread;
    private OnAudioDataListener listener;

    public interface OnAudioDataListener {
        void onAudioData(byte[] data, int length);
    }

    public AudioCapture(MediaProjection projection) {
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q && projection != null) {
                // Android 10+：采集系统播放声音（内放，耳机/外放都可捕获）
                AudioPlaybackCaptureConfiguration config =
                        new AudioPlaybackCaptureConfiguration.Builder(projection)
                                .addMatchingUsage(AudioAttributes.USAGE_MEDIA)
                                .addMatchingUsage(AudioAttributes.USAGE_GAME)
                                .addMatchingUsage(AudioAttributes.USAGE_VOICE_COMMUNICATION)
                                .build();
                AudioFormat format = new AudioFormat.Builder()
                        .setEncoding(AUDIO_FORMAT)
                        .setSampleRate(SAMPLE_RATE)
                        .setChannelMask(CHANNEL_CONFIG)
                        .build();
                audioRecord = new AudioRecord.Builder()
                        .setAudioFormat(format)
                        .setBufferSizeInBytes(BUFFER_SIZE)
                        .setAudioPlaybackCaptureConfig(config)
                        .build();
                Log.i(TAG, "System audio capture created");
            }
        } catch (Exception e) {
            Log.w(TAG, "System audio capture failed", e);
            audioRecord = null;
        }
    }

    public void setOnAudioDataListener(OnAudioDataListener l) {
        this.listener = l;
    }

    public synchronized boolean start() {
        if (audioRecord == null) return false;
        try {
            audioRecord.startRecording();
            running.set(true);
            captureThread = new Thread(() -> {
                byte[] buffer = new byte[BUFFER_SIZE];
                while (running.get()) {
                    try {
                        int read = audioRecord.read(buffer, 0, buffer.length);
                        if (read > 0 && listener != null) {
                            try {
                                listener.onAudioData(buffer, read);
                            } catch (Throwable t) {
                                Log.w(TAG, "audio listener error", t);
                            }
                        }
                    } catch (Throwable t) {
                        Log.w(TAG, "audio read error", t);
                        break;
                    }
                }
            }, "Audio-Capture");
            captureThread.start();
            Log.i(TAG, "Audio capture started, buffer size=" + BUFFER_SIZE);
            return true;
        } catch (Throwable e) {
            Log.e(TAG, "Audio start failed", e);
            return false;
        }
    }

    public synchronized void stop() {
        running.set(false);
        Thread t = captureThread;
        captureThread = null;
        if (t != null) {
            t.interrupt();
        }
        AudioRecord r = audioRecord;
        audioRecord = null;
        if (r != null) {
            try { r.stop(); } catch (Throwable e) {}
            try { r.release(); } catch (Throwable e) {}
        }
    }
}
